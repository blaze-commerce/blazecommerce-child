<?php
/**
 * Constants defined in this file are to help phpstan analyze code where constants outside the plugin (WordPress core constants, etc) are being used.
 *
 * @package WPGraphQL/WooCommerce
 */

define( 'WOOGRAPHQL_PRO_AUTOLOAD', true );
define( 'WOOGRAPHQL_PRO_VERSION', '1.3.3' );
define( 'WOOGRAPHQL_PRO_PLUGIN_FILE', 'woographql-pro.php' );
define( 'WOOGRAPHQL_PRO_PLUGIN_DIR', '' );
define( 'WOOGRAPHQL_PRO_PLUGIN_URL', '' );
define( 'WP_PLUGIN_DIR', '' );
