<?php
/**
 * Registers Composite Products CPTs and other business logic into the WooGraphQL infrastructure.
 *
 * @package \WPGraphQL\WooCommerce\Pro
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro;

/**
 * Class Composite_Products_Filters
 */
class Composite_Products_Filters {
	/**
	 * Composite_Products_Filters constructor
	 */
	public function __construct() {
		// Add product types.
		add_filter( 'graphql_woocommerce_product_types', [ $this, 'add_product_types' ], 10 );

		// Add product enumeration values.
		add_filter( 'graphql_product_types_enum_values', [ $this, 'add_product_enums' ], 10 );

		// Add composite cart item type.
		add_filter( 'woographql_cart_item_type', [ $this, 'resolve_composite_cart_item' ], 10, 2 );
	}

	/**
	 * Adds "composite" type to product types list.
	 *
	 * @param array $product_types  Product types array.
	 *
	 * @return array
	 */
	public function add_product_types( $product_types ) {
		$product_types['composite'] = 'CompositeProduct';

		return $product_types;
	}

	/**
	 * Adds the "COMPOSITE" enum value to the "ProductTypes" enum.
	 *
	 * @param array $values  Product type enumeration values.
	 *
	 * @return array
	 */
	public function add_product_enums( $values ) {
		$values = array_merge(
			[
				'COMPOSITE' => [
					'value'       => 'composite',
					'description' => __( 'A composite product', 'woographql-pro' ),
				],
			],
			$values
		);

		return $values;
	}

	/**
	 * Adds the "CompositeCartItem" type to the cart item type list.
	 *
	 * @param string $cart_item_type  Cart item type.
	 * @param array  $cart_item       Cart item data.
	 *
	 * @return string
	 */
	public function resolve_composite_cart_item( $cart_item_type, $cart_item ) {
		if ( in_array( 'composite_data', array_keys( $cart_item ), true ) ) {
			$cart_item_type = 'CompositeCartItem';
		}

		return $cart_item_type;
	}
}
