<?php
/**
 * Responsible for validating plugin license and checking/applying updates.
 *
 * @package WPGraphQL\WooCommerce\Pro
 */

namespace WPGraphQL\WooCommerce\Pro;

/**
 * Class Upgrade
 */
class Upgrade {
	/**
	 * The plugin remote update path
	 *
	 * @var string
	 */
	private $update_url;

	/**
	 * Plugin Slug (plugin_directory/plugin_file.php)
	 *
	 * @var string
	 */
	private $plugin_slug;

	/**
	 * Plugin name (plugin_file)
	 *
	 * @var string
	 */
	private $slug;

	/**
	 * The cache key.
	 *
	 * @var string
	 */
	private $cache_key;

	/**
	 * Whether to allow caching.
	 *
	 * @var bool
	 */
	private $cache_allowed;

	/**
	 * Upgrade constructor
	 */
	public function __construct() {
		$this->cache_key     = 'woographql_pro_updates';
		$this->cache_allowed = true;
		$this->update_url    = 'https://woographql.com';

		// Set the Plugin Slug.
		$this->plugin_slug = get_plugin_slug();
		list ($t1, $t2)    = explode( '/', $this->plugin_slug );
		$this->slug        = str_replace( '.php', '', $t2 );

		add_filter( 'plugins_api', [ $this, 'info' ], 20, 3 );
		add_filter( 'site_transient_update_plugins', [ $this, 'update' ] );
		add_action( 'update_option_woographql_settings', [ $this, 'activate_after_license_change' ], 10, 2 );
		add_filter( 'pre_update_option_woographql_settings', [ $this, 'deactivate_before_license_change' ], 10, 2 );
		add_action( 'upgrader_process_complete', [ $this, 'purge' ], 10, 2 );
	}

	/**
	 * Fetches plugin info
	 *
	 * @return false|object{
	 *  name: string,
	 *  slug: string,
	 *  version: string,
	 *  tested: string,
	 *  requires: string,
	 *  author: string,
	 *  authorProfile: string,
	 *  requiresPhp: string,
	 *  licenseValid: bool,
	 *  downloadId: string,
	 *  tested: string,
	 *  sections: object{ description: string, installation: string, changelog: string },
	 *  banners: object{ high: string, low: string },
	 * }
	 */
	public function fetch_plugin_info() {
		// Get license.
		$license = get_graphql_setting( 'pro_license', false, 'woographql_settings' );
		if ( empty( $license ) ) {
			return false;
		}

		/**
		 * Encoded license.
		 * 
		 * @var string
		 */
		$request_body = wp_json_encode( [ 'license' => $license ] );

		$response_body = is_multisite() ? get_site_transient( $this->cache_key ) : get_transient( $this->cache_key );
		if ( false === $response_body || ! $this->cache_allowed ) {
			// Send request for plugin info.
			$response = wp_remote_post(
				"{$this->update_url}/api/pro-info",
				[
					'headers' => [ 'Content-Type' => 'application/json' ],
					'body'    => $request_body,
				]
			);

			// Decode response if request successful.
			$response_body = null;
			$response_code = wp_remote_retrieve_response_code( $response );
			if ( 200 === $response_code ) {
				$response_body = json_decode( wp_remote_retrieve_body( $response ) );

				is_multisite()
					? set_site_transient( $this->cache_key, $response_body, DAY_IN_SECONDS )
					: set_transient( $this->cache_key, $response_body, DAY_IN_SECONDS );
			} elseif ( is_wp_error( $response ) ) {
				return false;
			} else {
				return false;
			}
		}//end if

		return $response_body;
	}

	/**
	 * Filters the response for the current WordPress.org Plugin Installation API request.
	 *
	 * @param false|array|object{ name: string, slug: string, version: string, tested: string, requires: string, author: string, author_profile: string, requires_php: string, tested: string, download_link: string, trunk: string, sections: array, banners: array, } $result  The result object or array. Default false.
	 * @param string                                                                                                                                                                                                                                                    $action  The type of information being requested from the Plugin Installation API.
	 * @param object{ slug: string }                                                                                                                                                                                                                                    $args    Plugin API arguments.
	 *
	 * @return false|object|array
	 */
	public function info( $result, $action, $args ) {

		// Bail early if not plugin information not being requested.
		if ( 'plugin_information' !== $action ) {
			return $result;
		}

		// Bail early if WPGraphQL is not active.
		if ( ! class_exists( 'WPGraphQL' ) ) {
			return $result;
		}

		// Bail early if it is not our plugin.
		if ( $this->slug !== $args->slug ) {
			return $result;
		}

		// Send request for plugin info.
		$response_body = $this->fetch_plugin_info();

		// Bail early if request failed.
		if ( empty( $response_body ) ) {
			return $result;
		}

		/**
		 * Map and return response data.
		 */
		$result = new \stdClass();

		$result->name           = $response_body->name;
		$result->slug           = $response_body->slug;
		$result->version        = $response_body->version;
		$result->tested         = $response_body->tested;
		$result->requires       = $response_body->requires;
		$result->author         = $response_body->author;
		$result->author_profile = $response_body->authorProfile; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$result->requires_php   = $response_body->requiresPhp; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$result->tested         = $response_body->tested;
		// $result->last_updated   = $response_body->last_updated;

		// Map download link if license is valid.
		if ( $response_body->licenseValid ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$download_link         = "{$this->update_url}/api/downloads/{$response_body->downloadId}";
			$result->download_link = $download_link;
			$result->trunk         = $download_link;
		} else {
			$result->download_link = '';
			$result->trunk         = '';
		}

		$result->sections = [
			'description'  => $response_body->sections->description,
			'installation' => $response_body->sections->installation,
			'changelog'    => $response_body->sections->changelog,
		];

		if ( ! empty( $response_body->banners ) ) {
			$result->banners = [
				'low'  => $response_body->banners->low,
				'high' => $response_body->banners->high,
			];
		}

		return $result;
	}

	/**
	 * Intercept WordPress updater data.
	 *
	 * @param object{ checked: bool, response: array } $transient  Update transient data.
	 *
	 * @return object
	 */
	public function update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		// Bail early if WPGraphQL is not active.
		if ( ! class_exists( 'WPGraphQL' ) ) {
			return $transient;
		}

		$response_body = $this->fetch_plugin_info();

		// Map and return plugin info if new version returned.
		if (
			$response_body
			&& $response_body->licenseValid // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			&& version_compare( WOOGRAPHQL_PRO_VERSION, $response_body->version, '<' )
			&& version_compare( $response_body->requires, get_bloginfo( 'version' ), '<=' )
			&& version_compare( $response_body->requiresPhp, PHP_VERSION, '<' ) // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		) {
			$download_link = "{$this->update_url}/api/downloads/{$response_body->downloadId}";

			$result              = new \stdClass();
			$result->slug        = $this->slug;
			$result->plugin      = $this->plugin_slug;
			$result->new_version = $response_body->version;
			$result->tested      = $response_body->tested;
			$result->url         = $this->update_url;
			$result->package     = $download_link;

			$transient->response[ $result->plugin ] = $result; // @phpstan-ignore-line
		}

		return $transient;
	}

	/**
	 * Returns keys for values changed
	 *
	 * @param array $values      New values.
	 * @param array $old_values  Old values.
	 * @return array
	 */
	public function get_changed_values( $values, $old_values ) {
		// Flatten arrays.
		foreach ( [ &$values, &$old_values ] as &$array ) {
			foreach ( $array as $key => &$value ) {
				if ( is_array( $value ) || \is_object( $value ) ) {
					$value = wp_json_encode( $value );
				}
			}
		}

		return array_keys( array_diff_assoc( $old_values, $values ) );
	}

	/**
	 * Fires license deactivation before the license is changed.
	 *
	 * @since 2.9.0
	 *
	 * @param mixed  $value      The new, unserialized option value.
	 * @param string $old_value  Name of the option.
	 *
	 * @return mixed
	 */
	public function deactivate_before_license_change( $value, $old_value ) {
		$old_value        = is_string( $old_value ) ? [] : $old_value;
		$changed_settings = $this->get_changed_values( $value, $old_value );
		if ( in_array( 'pro_license', $changed_settings, true ) ) {
			$this->on_deactivation();
			is_multisite()
				? delete_site_transient( $this->cache_key )
				: delete_transient( $this->cache_key );
		}

		return $value;
	}

	/**
	 * Fires license activation if license was changed.
	 *
	 * @param mixed $old_value The old option value.
	 * @param mixed $value     The new option value.
	 */
	public function activate_after_license_change( $old_value, $value ): void {
		$old_value        = is_string( $old_value ) ? [] : $old_value;
		$changed_settings = $this->get_changed_values( $value, $old_value );
		if ( in_array( 'pro_license', $changed_settings, true ) ) {
			$this->on_activation();
			is_multisite()
				? delete_site_transient( $this->cache_key )
				: delete_transient( $this->cache_key );
		}
	}

	/**
	 * Plugin activation callback
	 *
	 * @return void
	 */
	public function on_activation() {
		// Bail early if WPGraphQL is not active.
		if ( ! class_exists( 'WPGraphQL' ) ) {
			return;
		}

		// Get license.
		$license = get_graphql_setting( 'pro_license', '', 'woographql_settings' );

		/**
		 * Encode license.
		 * 
		 * @var string
		 */
		$request_body = wp_json_encode(
			[
				'mutation' => 'activate',
				'input'    => [ 'license' => $license ],
			]
		);

		// Send license activation request.
		$response = wp_remote_post(
			"{$this->update_url}/api/license",
			[
				'headers' => [ 'Content-Type' => 'application/json' ],
				'body'    => $request_body,
			]
		);

		// Bail early if activation request failed.
		$response_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $response_code ) {
			return;
		}

		// Get response.
		$response_body = json_decode( wp_remote_retrieve_body( $response ) );

		// Save activation details if activation confirmed.
		if ( $response_body->activated ) {
			$pro_settings                        = get_option( 'woographql_settings' );
			$pro_settings['activation_id']       = $response_body->activationId; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$pro_settings['activation_instance'] = $response_body->instance;
			update_option( 'woographql_settings', $pro_settings );
		}
	}

	/**
	 * Plugin deactivation callback.
	 *
	 * @return void
	 */
	public function on_deactivation() {
		// Bail early if WPGraphQL is not active.
		if ( ! class_exists( 'WPGraphQL' ) ) {
			return;
		}

		// Create input and retrieve stored license.
		$input = [ 'license' => get_graphql_setting( 'pro_license', '', 'woographql_settings' ) ];
		// Get activation ID and instance if available.
		$activation_id = get_graphql_setting( 'activation_id', '', 'woographql_settings' );
		if ( ! empty( $activation_id ) ) {
			$input['activationId'] = $activation_id;
		}
		$instance = get_graphql_setting( 'activation_instance', '', 'woographql_settings' );
		if ( ! empty( $instance ) ) {
			$input['instance'] = $instance;
		}

		/**
		 * Encode request body.
		 * 
		 * @var string
		 */
		$request_body = wp_json_encode(
			[
				'mutation' => 'deactivate',
				'input'    => $input,
			]
		);

		// Send license deactivation request.
		$response = wp_remote_post(
			"{$this->update_url}/api/license",
			[
				'headers' => [ 'Content-Type' => 'application/json' ],
				'body'    => $request_body,
			]
		);

		// Bail early if deactivation request failed.
		$response_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $response_code ) {
			return;
		}

		// Get response.
		$response_body = json_decode( wp_remote_retrieve_body( $response ) );

		// Delete last activation info if deactivation confirmed.
		if ( $response_body->deactivated ) {
			$pro_settings = get_option( 'woographql_settings' );
			unset( $pro_settings['activation_id'] );
			unset( $pro_settings['activation_instance'] );
			update_option( 'woographql_settings', $pro_settings );
		}
	}

	/**
	 * Cache cleaner
	 *
	 * @param mixed $upgrader  Upgrader object.
	 * @param array $options   Options array.
	 * @return void
	 */
	public function purge( $upgrader, $options ) {
		if ( $this->cache_allowed && 'update' === $options['action'] && 'plugin' === $options['type'] ) {
			// just clean the cache when new plugin version is installed.
			is_multisite()
				? delete_site_transient( $this->cache_key )
				: delete_transient( $this->cache_key );
		}
	}
}
