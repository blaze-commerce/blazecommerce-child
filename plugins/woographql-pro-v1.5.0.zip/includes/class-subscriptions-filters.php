<?php
/**
 * Registers Subscriptions CPTs and other business logic into the WooGraphQL infrastructure.
 *
 * @package \WPGraphQL\WooCommerce\Pro
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro;

/**
 * Class Subscriptions_Filters
 */
class Subscriptions_Filters {
	/**
	 * Subscriptions_Filters constructor
	 */
	public function __construct() {
		// Add product types.
		add_filter( 'graphql_woocommerce_product_types', [ $this, 'add_product_types' ], 10 );
		add_filter( 'graphql_woocommerce_product_variation_types', [ $this, 'add_product_variation_types' ], 10 );

		// Add product enumeration values.
		add_filter( 'graphql_product_types_enum_values', [ $this, 'add_product_enums' ], 10 );

		// Auth URL filters.
		add_filter( 'woographql_auth_nonce_prefix', [ $this, 'get_nonce_prefix' ], 10, 2 );
		add_filter( 'woographql_auth_target_endpoint', [ $this, 'get_target_endpoint' ], 10, 2 );

		// Order Model filters.
		add_filter( 'woographql_order_model_data_post_type', [ $this, 'get_subscription_post_type' ], 10, 2 );
		add_filter( 'woographql_viewable_order_types', [ $this, 'add_subscription_to_view_orders' ], 10 );
	}

	/**
	 * Adds "*subscription" types to product types list.
	 *
	 * @param array $product_types  Product types array.
	 *
	 * @return array
	 */
	public function add_product_types( $product_types ) {
		$product_types['subscription']          = 'SubscriptionProduct';
		$product_types['variable-subscription'] = 'SubscriptionVariableProduct';

		return $product_types;
	}

	/**
	 * Adds "*subscription" types to product variation types list.
	 *
	 * @param array $variation_types  Product variation types array.
	 *
	 * @return array
	 */
	public function add_product_variation_types( $variation_types ) {
		$variation_types['subscription_variation'] = 'SubscriptionProductVariation';

		return $variation_types;
	}

	/**
	 * Adds "*SUBSCRIPTION" enum values to the "ProductTypes" enum.
	 *
	 * @param array $values  Product type enumeration values.
	 *
	 * @return array
	 */
	public function add_product_enums( $values ) {
		$values = array_merge(
			[
				'SUBSCRIPTION'           => [
					'value'       => 'subscription',
					'description' => __( 'A subscription product', 'woographql-pro' ),
				],
				'VARIABLE_SUBSCRIPTION'  => [
					'value'       => 'variable-subscription',
					'description' => __( 'A subscription variable product', 'woographql-pro' ),
				],
				'SUBSCRIPTION_VARIATION' => [
					'value'       => 'subscription_variation',
					'description' => __( 'A subscription variable product variation', 'woographql-pro' ),
				],
			],
			$values
		);

		return $values;
	}

	/**
	 * Returns the nonce action prefix for the provided field.
	 *
	 * @param string|null $nonce_prefix  Nonce action prefix.
	 * @param string      $field         Field.
	 *
	 * @return string|null
	 */
	public function get_nonce_prefix( $nonce_prefix, $field ) {
		switch ( $field ) {
			case 'change_subscription_payment_method_url':
				return 'change-sub_';
			case 'renew_subscription_payment_method_url':
				return 'renew-sub_';
			default:
				return $nonce_prefix;
		}
	}

	/**
	 * Returns the target endpoint url for the provided field.
	 *
	 * @param string|null $endpoint  Endpoint URL.
	 * @param string      $field     Field.
	 *
	 * @return string|null
	 */
	public function get_target_endpoint( $endpoint, $field ) {
		if ( ! isset( $_REQUEST['sub'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return $endpoint;
		}

		$subscription_id = sanitize_text_field( wp_unslash( $_REQUEST['sub'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		switch ( $field ) {
			case 'change_subscription_payment_method_url':
				return wc_get_endpoint_url( 'subscription-payment-method', $subscription_id, wc_get_page_permalink( 'myaccount' ) );
			case 'renew_subscription_payment_method_url':
				return esc_url_raw(
					add_query_arg(
						[
							'subscription_renewal_early' => $subscription_id,
							'subscription_renewal'       => 'true',
						],
						wc_get_endpoint_url( 'edit-account' )
					)
				);
			default:
				return $field;
		}
	}

	/**
	 * Returns the post type for the provided model.
	 *
	 * @param string|null                        $post_type Post type of model.
	 * @param \WPGraphQL\WooCommerce\Model\Order $model     Model instance.
	 *
	 * @return string|null
	 */
	public function get_subscription_post_type( $post_type, $model ) {
		if ( $model->get_type() === 'shop_subscription' ) {
			return 'shop_subscription';
		}
		return $post_type;
	}

	/**
	 * Adds "shop_subscription" to the list of viewable orders.
	 *
	 * @param string[] $order_types  Order types.
	 *
	 * @return string[]
	 */
	public function add_subscription_to_view_orders( $order_types ) {
		$order_types[] = 'shop_subscription';
		return $order_types;
	}
}
