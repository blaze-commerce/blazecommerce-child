<?php
/**
 * Registers Product Bundles CPTs and other business logic into the WooGraphQL infrastructure.
 *
 * @package \WPGraphQL\WooCommerce\Pro
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro;

/**
 * Class Bundles_Filters
 */
class Bundles_Filters {
	/**
	 * Bundles_Filters constructor
	 */
	public function __construct() {
		// Add product types.
		add_filter( 'graphql_woocommerce_product_types', [ $this, 'add_product_types' ], 10 );

		// Add product enumeration values.
		add_filter( 'graphql_product_types_enum_values', [ $this, 'add_product_enums' ], 10 );

		// Add bundle cart item type.
		add_filter( 'woographql_cart_item_type', [ $this, 'resolve_bundle_cart_item' ], 10, 2 );
	}

	/**
	 * Adds "bundle" type to product types list.
	 *
	 * @param array $product_types  Product types array.
	 *
	 * @return array
	 */
	public function add_product_types( $product_types ) {
		$product_types['bundle'] = 'BundleProduct';

		return $product_types;
	}

	/**
	 * Add "BUNDLE" enum value to the "ProductTypes" enum.
	 *
	 * @param array $values  Product type enumeration values.
	 *
	 * @return array
	 */
	public function add_product_enums( $values ) {
		$values = array_merge(
			[
				'BUNDLE' => [
					'value'       => 'bundle',
					'description' => __( 'A product bundle', 'woographql-pro' ),
				],
			],
			$values
		);

		return $values;
	}

	/**
	 * Resolves the bundle cart item type.
	 *
	 * @param string $type_name  The cart item type name.
	 * @param array  $cart_item  The cart item data.
	 *
	 * @return string
	 */
	public function resolve_bundle_cart_item( $type_name, $cart_item ) {
		if ( ! empty( $cart_item['bundled_items'] ) ) {
			$type_name = 'BundleCartItem';
		}

		return $type_name;
	}
}
