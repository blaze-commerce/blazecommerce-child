<?php
/**
 * Initializes a singleton instance of WooGraphQL_Pro
 *
 * @package WPGraphQL\WooCommerce\Pro
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\WPGraphQL\WooCommerce\Pro\WooGraphQL_Pro' ) ) :

	/**
	 * Class WooGraphQL_Pro
	 */
	final class WooGraphQL_Pro {
		/**
		 * Stores the instance of the WooGraphQL_Pro class
		 *
		 * @var ?\WPGraphQL\WooCommerce\Pro\WooGraphQL_Pro The one true WooGraphQL_Pro
		 */
		private static $instance;

		/**
		 * WooGraphQL_Pro constructor
		 */
		private function __construct() {
			add_action( 'graphql_woocommerce_init', [ $this, 'init' ] );
			add_action( 'plugins_loaded', [ $this, 'render_admin_notices' ] );
		}

		/**
		 * Returns a WooGraphQL_Pro Instance.
		 *
		 * @return \WPGraphQL\WooCommerce\Pro\WooGraphQL_Pro
		 */
		public static function instance() {
			if ( ! isset( self::$instance ) || ! ( is_a( self::$instance, self::class ) ) ) {
				self::$instance = new self();
			}

			// Return the WooGraphQL_Pro Instance.
			return self::$instance;
		}

		/**
		 * Throw error on object clone.
		 * The whole idea of the singleton design pattern is that there is a single object
		 * therefore, we don't want the object to be cloned.
		 *
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'WooGraphQL_Pro class should not be cloned.', 'woographql-pro' ), '0.0.1' );
		}

		/**
		 * Disable unserializing of the class.
		 *
		 * @return void
		 */
		public function __wakeup() {
			// De-serializing instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'De-serializing instances of the WooGraphQL_Pro class is not allowed', 'woographql-pro' ), '0.0.1' );
		}

		/**
		 * Checks if WooGraphQL Pro required plugins are installed and activated
		 *
		 * @return array
		 */
		public function dependencies_not_ready() {
			$missing_dependencies = [];
			if ( ! class_exists( '\WPGraphQL' ) ) {
				$missing_dependencies['WPGraphQL'] = 'https://wpgraphql.com';
			}
			if ( ! class_exists( '\WooCommerce' ) ) {
				$missing_dependencies['WooCommerce'] = 'https://woocommerce.com';
			}
			if ( ! defined( 'WPGRAPHQL_WOOCOMMERCE_VERSION' ) ) {
				$missing_dependencies['WooGraphQL'] = 'https://woographql.com';
			}

			return $missing_dependencies;
		}

		/**
		 * Render admin notices for all missing dependencies.
		 *
		 * @return void
		 */
		public function render_admin_notices() {
			$not_ready = $this->dependencies_not_ready();

			foreach ( $not_ready as $name => $url ) {
				add_missing_dependencies_notice( $url, $name );
			}
		}

		/**
		 * Initializes WooGraphQL Pro.
		 *
		 * @return void
		 */
		public function init() {
			// Bail early, if some dependencies still needed.
			if ( ! empty( $this->dependencies_not_ready() ) ) {
				return;
			}

			// Load include files.
			$this->includes();

			// Initialize WooGraphQL Settings.
			new Admin();

			// Setup schema.
			$this->setup();

			/**
			 * Fire off init action
			 *
			 * @param self $instance The instance of the WooGraphQL_Pro class
			 */
			do_action( 'woographql_pro_init', $this );
		}

		/**
		 * Include required files.
		 * Uses composer's autoload
		 *
		 * @return void
		 */
		private function includes() {
			$include_directory_path = get_includes_directory();

			// Include admin class files.
			require $include_directory_path . 'admin/class-section.php';
			require $include_directory_path . 'admin/class-general.php';

			// Include enum type class files.
			require $include_directory_path . 'type/enum/class-bundle-price-display-context-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-component-option-select-action-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-component-option-style-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-component-options-type-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-component-pagination-style-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-component-selection-detail-visibility-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-component-subtotal-visibility-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-form-location-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-layout-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-scenario-condition-compare-enum.php';
			require $include_directory_path . 'type/enum/class-composite-product-shop-price-calc-options.php';
			require $include_directory_path . 'type/enum/class-composite-product-sold-individually-context-enum.php';
			require $include_directory_path . 'type/enum/class-product-addon-display-as-enum.php';
			require $include_directory_path . 'type/enum/class-product-addon-field-enum.php';
			require $include_directory_path . 'type/enum/class-product-addon-price-adjust-enum.php';
			require $include_directory_path . 'type/enum/class-product-addon-short-text-restriction-enum.php';
			require $include_directory_path . 'type/enum/class-product-addon-title-format-enum.php';
			require $include_directory_path . 'type/enum/class-product-bundle-min-max-enum.php';
			require $include_directory_path . 'type/enum/class-subscription-price-display-context-enum.php';
			require $include_directory_path . 'type/enum/class-subscription-pricing-properties-enum.php';
			require $include_directory_path . 'type/enum/class-subscription-statuses-enum.php';

			// Include input type class files.
			require $include_directory_path . 'type/input/class-composite-product-configuration-input.php';
			require $include_directory_path . 'type/input/class-product-addon-input.php';
			require $include_directory_path . 'type/input/class-bundle-item-input.php';

			// Include interface type class files.
			require $include_directory_path . 'type/interface/class-product-addon-field-interface.php';

			// Include object type class files.
			require $include_directory_path . 'type/object/class-bundle-cart-item.php';
			require $include_directory_path . 'type/object/class-bundle-product.php';
			require $include_directory_path . 'type/object/class-composite-cart-item.php';
			require $include_directory_path . 'type/object/class-composite-product.php';
			require $include_directory_path . 'type/object/class-customer.php';
			require $include_directory_path . 'type/object/class-product-addon-field-types.php';
			require $include_directory_path . 'type/object/class-subscription.php';
			require $include_directory_path . 'type/object/class-subscription-product.php';

			// Include mutation hooks class files.
			require $include_directory_path . 'mutation/hooks/class-process-bundle-configuration.php';
			require $include_directory_path . 'mutation/hooks/class-process-composite-configuration.php';
			require $include_directory_path . 'mutation/hooks/class-process-product-addons.php';

			// Include mutation class files.
			require $include_directory_path . 'mutation/class-add-bundle-to-cart.php';
			require $include_directory_path . 'mutation/class-add-composite-to-cart.php';
			require $include_directory_path . 'mutation/class-cancel-subscription.php';
			require $include_directory_path . 'mutation/class-reactivate-subscription.php';
			require $include_directory_path . 'mutation/class-subscription-change-payment-method.php';

			// Include main plugin class files.
			require $include_directory_path . 'class-admin.php';
			require $include_directory_path . 'class-bundles-filters.php';
			require $include_directory_path . 'class-composite-products-filters.php';
			require $include_directory_path . 'class-product-addons-filters.php';
			require $include_directory_path . 'class-subscriptions-filters.php';
			require $include_directory_path . 'class-type-registry.php';
		}

		/**
		 * Returns true if WooCommerce Product Bundles is enabled on the settings page.
		 *
		 * @return boolean
		 */
		public static function is_product_bundles_enabled() {
			return 'on' === get_graphql_setting( 'bundle_products', 'off', 'woographql_settings' )
				|| defined( 'WOOGRAPHQL_PRO_TEST_MODE' ) && true === WOOGRAPHQL_PRO_TEST_MODE;
		}

		/**
		 * Returns true if WooCommerce Product Bundles is installed and activated.
		 *
		 * @return boolean
		 */
		public static function is_product_bundles_active() {
			return class_exists( '\WC_Bundles' );
		}

		/**
		 * Returns true if WooCommerce Subscriptions is enabled on the settings page.
		 *
		 * @return boolean
		 */
		public static function is_subscriptions_enabled() {
			return 'on' === get_graphql_setting( 'woo_subscriptions', 'off', 'woographql_settings' )
				|| defined( 'WOOGRAPHQL_PRO_TEST_MODE' ) && true === WOOGRAPHQL_PRO_TEST_MODE;
		}

		/**
		 * Returns true if WooCommerce Subscriptions is installed and activated.
		 *
		 * @return boolean
		 */
		public static function is_subscriptions_active() {
			return class_exists( '\WC_Subscriptions' );
		}

		/**
		 * Returns true if Composite Products is enabled on the settings page.
		 *
		 * @return boolean
		 */
		public static function is_composite_products_enabled() {
			return 'on' === get_graphql_setting( 'composite_products', 'off', 'woographql_settings' )
				|| defined( 'WOOGRAPHQL_PRO_TEST_MODE' ) && true === WOOGRAPHQL_PRO_TEST_MODE;
		}

		/**
		 * Returns true if Composite Products is installed and activated.
		 *
		 * @return boolean
		 */
		public static function is_composite_products_active() {
			return defined( 'WC_CP_VERSION' );
		}

		/**
		 * Returns true if Product Add-ons is enabled on the settings page.
		 *
		 * @return boolean
		 */
		public static function is_product_addons_enabled() {
			return 'on' === get_graphql_setting( 'product_addons', 'off', 'woographql_settings' )
				|| defined( 'WOOGRAPHQL_PRO_TEST_MODE' ) && true === WOOGRAPHQL_PRO_TEST_MODE;
		}

		/**
		 * Returns true if Product Add-ons is installed and activated.
		 *
		 * @return boolean
		 */
		public static function is_product_addons_active() {
			return defined( 'WC_PRODUCT_ADDONS_VERSION' );
		}

		/**
		 * Returns true if the "WOOGRAPHQL_PRO_TEST_MODE" constant is to "true"
		 * 
		 * @return boolean
		 */
		public static function is_test_mode() {
			return defined( 'WOOGRAPHQL_PRO_TEST_MODE' ) && true === WOOGRAPHQL_PRO_TEST_MODE;
		}

		/**
		 * Sets up WooGraphQL schema.
		 */
		private function setup(): void {
			if ( self::is_product_bundles_enabled() && self::is_product_bundles_active() ) {
				new Bundles_Filters();
			}

			if ( self::is_subscriptions_enabled() && self::is_subscriptions_active() ) {
				new Subscriptions_Filters();
			}

			if ( self::is_composite_products_enabled() && self::is_composite_products_active() ) {
				new Composite_Products_Filters();
			}

			if ( self::is_product_addons_enabled() && self::is_product_addons_active() ) {
				new Product_Addons_Filters();
			}

			// Initialize WooGraphQL TypeRegistry.
			$registry = new Type_Registry();
			add_action( 'graphql_register_types', [ $registry, 'init' ], 20, 1 );
		}
	}
endif;
