<?php
/**
 * Registers Product Addon CPTs and other business logic into the WooGraphQL infrastructure.
 *
 * @package \WPGraphQL\WooCommerce\Pro
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro;

/**
 * Class Product_Addons_Filters
 */
class Product_Addons_Filters {
	/**
	 * Product_Addons_Filters constructor
	 */
	public function __construct() {
		// Add register CPTs.
		add_filter( 'register_post_type_args', [ $this, 'register_post_types' ], 10, 2 );
	}

	/**
	 * Registers WooCommerce Product Addons post-types to be used in GraphQL schema
	 *
	 * @param array  $args      - allowed post-types.
	 * @param string $post_type - name of taxonomy being checked.
	 *
	 * @return array
	 */
	public function register_post_types( $args, $post_type ) {
		if ( 'global_product_addon' === $post_type ) {
			$args['show_in_graphql']     = true;
			$args['graphql_single_name'] = 'ProductAddon';
			$args['graphql_plural_name'] = 'ProductAddons';
		}

		return $args;
	}

	/**
	 * Returns the support product addon field types.
	 *
	 * @return array<string, string>
	 */
	public static function get_enabled_addon_types() {
		return apply_filters(
			'graphql_woocommerce_product_addon_types',
			[
				'multiple_choice'  => 'AddonMultipleChoice',
				'checkbox'         => 'AddonCheckbox',
				'custom_text'      => 'AddonShortText',
				'custom_textarea'  => 'AddonLongText',
				'file_upload'      => 'AddonFileUpload',
				'custom_price'     => 'AddonCustomerDefinedPrice',
				'input_multiplier' => 'AddonQuantity',
				'heading'          => 'AddonHeading',
			]
		);
	}
}
