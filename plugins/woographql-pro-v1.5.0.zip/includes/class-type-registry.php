<?php
/**
 * Registers WooGraphQL Pro types to the schema.
 *
 * @package \WPGraphQL\WooCommerce\Pro
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro;

use WPGraphQL\WooCommerce\WooCommerce_Filters;

/**
 * Class Type_Registry
 */
class Type_Registry {
	/**
	 * Registers WooGraphQL Pro types, connections, unions, and mutations to GraphQL schema.
	 *
	 * @return void
	 */
	public function init() {
		// Load common types.
		// objects.
		$ql_session_handled_enabled = ! WooCommerce_Filters::is_session_handler_disabled();
		$enabled_url_fields         = WooCommerce_Filters::enabled_authorizing_url_fields();
		if ( $ql_session_handled_enabled && ! empty( $enabled_url_fields ) ) {
			Type\WPObject\Customer::register_authorizing_url_fields( array_keys( $enabled_url_fields ) );
		}

		// If Composite Products enabled and active.
		if ( WooGraphQL_Pro::is_composite_products_enabled() && WooGraphQL_Pro::is_composite_products_active() ) {
			// enums.
			Type\WPEnum\Composite_Product_Component_Option_Select_Action_Enum::register();
			Type\WPEnum\Composite_Product_Component_Option_Style_Enum::register();
			Type\WPEnum\Composite_Product_Component_Options_Type_Enum::register();
			Type\WPEnum\Composite_Product_Component_Pagination_Style_Enum::register();
			Type\WPEnum\Composite_Product_Component_Selection_Detail_Visibility_Enum::register();
			Type\WPEnum\Composite_Product_Component_Subtotal_Visibility_Enum::register();
			Type\WPEnum\Composite_Product_Form_Location_Enum::register();
			Type\WPEnum\Composite_Product_Layout_Enum::register();
			Type\WPEnum\Composite_Product_Scenario_Condition_Compare_Enum::register();
			Type\WPEnum\Composite_Product_Shop_Price_Calc_Options::register();
			Type\WPEnum\Composite_Product_Sold_Individually_Context_Enum::register();

			// inputs.
			Type\WPInputObject\Composite_Product_Configuration_Input::register();

			// object/union/interfaces types.
			Type\WPObject\Composite_Cart_Item::register();
			Type\WPObject\Composite_Product::register();

			// mutations.
			Mutation\Hooks\Process_Composite_Configuration::register();
			Mutation\Add_Composite_To_Cart::register_mutation();
		}//end if

		// If Product Addons enabled and active.
		if ( WooGraphQL_Pro::is_product_addons_enabled() && WooGraphQL_Pro::is_product_addons_active() ) {
			// enums.
			Type\WPEnum\Product_Addon_Title_Format_Enum::register();
			Type\WPEnum\Product_Addon_Field_Enum::register();
			Type\WPEnum\Product_Addon_Display_As_Enum::register();
			Type\WPEnum\Product_Addon_Price_Adjust_Enum::register();
			Type\WPEnum\Product_Addon_Short_Text_Restriction_Enum::register();

			// inputs.
			Type\WPInputObject\Product_Addon_Input::register();

			// object/interface types.
			Type\WPInterface\Product_Addon_Field_Interface::register_interface();
			Type\WPObject\Product_Addon_Field_Types::register_field_types();

			// mutations.
			Mutation\Hooks\Process_Product_Addons::register();
		}

		// If Product Bundles enabled and active.
		if ( WooGraphQL_Pro::is_product_bundles_enabled() && WooGraphQL_Pro::is_product_bundles_active() ) {
			// enums.
			Type\WPEnum\Bundle_Price_Display_Context_Enum::register();
			Type\WPEnum\Product_Bundle_Min_Max_Enum::register();

			// inputs.
			Type\WPInputObject\Bundle_Item_Input::register();

			// object types.
			Type\WPObject\Bundle_Cart_Item::register();
			Type\WPObject\Bundle_Product::register();

			// mutations.
			Mutation\Hooks\Process_Bundle_Configuration::register();
			Mutation\Add_Bundle_To_Cart::register_mutation();
		}

		// if Woo Subscriptions types enabled and active.
		if ( WooGraphQL_Pro::is_subscriptions_enabled() && WooGraphQL_Pro::is_subscriptions_active() ) {
			// enums.
			Type\WPEnum\Subscription_Pricing_Properties_Enum::register();
			Type\WPEnum\Subscription_Price_Display_Context_Enum::register();
			Type\WPEnum\Subscription_Statuses_Enum::register();

			// types.
			Type\WPObject\Subscription::register();
			Type\WPObject\Subscription_Product::register_types();

			// mutations.
			Mutation\Cancel_Subscription::register_mutation();
			Mutation\Reactivate_Subscription::register_mutation();
			Mutation\Subscription_Change_Payment_Method::register_mutation();
		}
	}
}
