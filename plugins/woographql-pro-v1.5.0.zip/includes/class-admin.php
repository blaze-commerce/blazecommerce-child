<?php
/**
 * Initializes a WooGraphQL Pro admin settings.
 *
 * @package WPGraphQL\WooCommerce\Pro
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro;

use WPGraphQL\Admin\Settings\Settings;
use WPGraphQL\WooCommerce\Pro\Admin\General;
use WPGraphQL\WooCommerce\Pro\WooGraphQL_Pro;

/**
 * Class Admin
 */
class Admin {
	/**
	 * Admin constructor
	 */
	public function __construct() {
		$this->load_actions();
		$this->load_filters();
	}

	/**
	 * Registers actions.
	 *
	 * @return void
	 */
	public function load_actions() {
		add_action( 'graphql_register_settings', [ $this, 'register_settings' ] );
	}

	/**
	 * Registers filters.
	 *
	 * @return void
	 */
	public function load_filters() {
		add_filter( 'woographql_enabled_authorizing_url_fields', [ $this, 'add_url_fields' ] );
		add_filter( 'woographql_settings_enable_authorizing_url_options', [ $this, 'add_url_options' ] );
		add_filter( 'woographql_authorizing_url_nonce_values', [ $this, 'add_url_nonce_values' ] );
	}

	/**
	 * Adds Woo Subscriptions Auth URL options to the all "authorizing_url" list
	 *
	 * @param array $url_fields Fields.
	 * @return array
	 */
	public function add_url_fields( $url_fields ) {
		if ( WooGraphQL_Pro::is_subscriptions_active() && WooGraphQL_Pro::is_subscriptions_enabled() ) {
			$url_fields = array_merge(
				$url_fields,
				[
					'change_subscription_payment_method_url' => 'change_subscription_payment_method_url',
					'renew_subscription_payment_method_url'  => 'renew_subscription_payment_method_url',
				]
			);
		}

		return $url_fields;
	}

	/**
	 * Adds Woo Subscriptions Auth URL options to the "authorizing_url_fields" options list
	 *
	 * @param array $url_options Options list.
	 * @return array
	 */
	public function add_url_options( $url_options ) {
		if ( WooGraphQL_Pro::is_subscriptions_active() && WooGraphQL_Pro::is_subscriptions_enabled() ) {
			$url_options = array_merge(
				$url_options,
				[
					'change_subscription_payment_method_url' => __( 'Change Subscription Payment Method URL. Field name: <strong>changeSubPaymentMethodUrl</strong>', 'woographql-pro' ),
					'renew_subscription_payment_method_url'  => __( 'Renew Subscription Payment Method URL. Field name: <strong>renewSubPaymentMethodUrl</strong>', 'woographql-pro' ),
				]
			);
		}

		return $url_options;
	}

	/**
	 * Adds Woo Subscriptions Auth URL Nonce param names to the Auth URL nonce param list
	 *
	 * @param array $nonce_values  Auth URL nonce param list.
	 * @return array
	 */
	public function add_url_nonce_values( $nonce_values ) {
		if ( WooGraphQL_Pro::is_subscriptions_active() && WooGraphQL_Pro::is_subscriptions_enabled() ) {
			$nonce_values = array_merge(
				$nonce_values,
				[
					'change_subscription_payment_method_url' => woographql_setting( 'change_subscription_payment_method_nonce_param', '_wc_change_sub' ),
					'renew_subscription_payment_method_url'  => woographql_setting( 'renew_subscription_payment_method_nonce_param', '_wc_renew_sub' ),
				]
			);
		}

		return $nonce_values;
	}

	/**
	 * Registers the WooGraphQL Settings tab.
	 *
	 * @param \WPGraphQL\Admin\Settings\Settings $manager  Settings Manager.
	 * @return void
	 */
	public function register_settings( Settings $manager ) {
		$manager->settings_api->register_section(
			'woographql_settings',
			[ 'title' => __( 'WooGraphQL', 'woographql-pro' ) ]
		);

		$manager->settings_api->register_fields(
			'woographql_settings',
			General::get_fields()
		);
	}
}
