<?php
/**
 * Defines WooGraphQL Pro's general settings.
 *
 * @package WPGraphQL\WooCommerce\Pro\Admin
 */

namespace WPGraphQL\WooCommerce\Pro\Admin;

use WPGraphQL\WooCommerce\Admin\General as CoreSettings;
use WPGraphQL\WooCommerce\Pro\WooGraphQL_Pro;

/**
 * General class
 */
class General extends Section {
	/**
	 * Returns General settings fields.
	 *
	 * @return array
	 */
	public static function get_fields() {
		$test_mode_status = WooGraphQL_Pro::is_test_mode() ? 'force enabled' : 'force disabled';
		$settings_status  = sprintf(
			/* translators: Test mode status */
			__( 'This setting is <strong>%s</strong>. The <strong>WOOGRAPHQL_PRO_TEST_MODE</strong> flag with code', 'woographql-pro' ),
			$test_mode_status
		);
		$enabled_authorizing_url_fields = woographql_setting( 'enable_authorizing_url_fields', [] );
		$enabled_authorizing_url_fields = ! empty( $enabled_authorizing_url_fields ) ? array_keys( $enabled_authorizing_url_fields ) : [];

		$change_subscription_payment_method_url_hardcoded = defined( 'CHANGE_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM' ) && is_string( CHANGE_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM );
		$renew_subscription_payment_method_url_hardcoded  = defined( 'RENEW_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM' ) && is_string( RENEW_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM );

		$product_bundles_value    = 'off';
		$composite_products_value = 'off';
		$product_addons_value     = 'off';
		$woo_subscriptions_value  = 'off';
		if ( WooGraphQL_Pro::is_test_mode() ) {
			$product_bundles_value    = WooGraphQL_Pro::is_product_bundles_active() ? 'on' : 'off';
			$composite_products_value = WooGraphQL_Pro::is_composite_products_active() ? 'on' : 'off';
			$product_addons_value     = WooGraphQL_Pro::is_product_addons_active() ? 'on' : 'off';
			$woo_subscriptions_value  = WooGraphQL_Pro::is_subscriptions_active() ? 'on' : 'off';
		} else {
			$product_bundles_value    = ! WooGraphQL_Pro::is_product_bundles_active() ? 'off' : get_graphql_setting( 'bundle_products', 'off', 'woographql_settings' );
			$composite_products_value = ! WooGraphQL_Pro::is_composite_products_active() ? 'off' : get_graphql_setting( 'composite_products', 'off', 'woographql_settings' );
			$product_addons_value     = ! WooGraphQL_Pro::is_product_addons_active() ? 'off' : get_graphql_setting( 'product_addons', 'off', 'woographql_settings' );
			$woo_subscriptions_value  = ! WooGraphQL_Pro::is_subscriptions_active() ? 'off' : get_graphql_setting( 'woo_subscriptions', 'off', 'woographql_settings' );
		}

		$license_desc = '';
		$license      = woographql_setting( 'pro_license', false );
		if ( ! empty( $license ) && 'no' !== woographql_setting( 'activation_id', 'no' ) ) {
			$license_desc = __( '<strong class="notice notice-success">License is valid</strong><br />', 'woographql-pro' );
		} elseif ( ! empty( $license ) && 'no' === woographql_setting( 'activation_id', 'no' ) ) {
			$license_desc = __( '<strong class="notice notice-error">License is invalid</strong><br />', 'woographql-pro' );
		} else {
			$license_desc = __( 'Input a valid <strong>WooGraphQL Pro<strong> license distributed upon purchased from a legal POS.', 'woographql-pro' );
		}

		$fields = [];
		if ( 'on' === $woo_subscriptions_value ) {
			$fields = array_merge(
				$fields,
				[
					[
						'name'              => 'change_subscription_payment_method_url_nonce_param',
						'label'             => __( 'Change Subscription Payment Method URL nonce name', 'woographql-pro' ),
						'desc'              => __( 'Query parameter name of the nonce included in the "changeSubscriptionPaymentMethodUrl" field', 'woographql-pro' )
							. ( $change_subscription_payment_method_url_hardcoded ? __( ' This setting is disabled. The "CHANGE_SUB_PAYMENT_URL_NONCE_PARAM" flag has been set with code', 'woographql-pro' ) : '' ),
						'type'              => 'text',
						'value'             => $change_subscription_payment_method_url_hardcoded ? CHANGE_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM : woographql_setting( 'change_subscription_payment_method_url_nonce_param', '_wc_change_sub' ),
						'disabled'          => defined( 'CHANGE_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM' ) || ! in_array( 'change_subscription_payment_method_url', $enabled_authorizing_url_fields, true ),
						'sanitize_callback' => static function ( $value ) {
							$other_nonces = CoreSettings::get_other_nonce_values( 'change_subscription_payment_method_url' );
							if ( in_array( $value, $other_nonces, true ) ) {
								add_settings_error(
									'change_subscription_payment_method_url_nonce_param',
									'unique',
									__( 'The <strong>Change Subscription Payment Method URL nonce name</strong> field must be unique', 'woographql-pro' ),
									'error'
								);
		
								return '_wc_change_sub';
							}
		
							return $value;
						},
					],
					[
						'name'              => 'renew_subscription_payment_method_url_nonce_param',
						'label'             => __( 'Renew Subscription Payment Method URL nonce name', 'woographql-pro' ),
						'desc'              => __( 'Query parameter name of the nonce included in the "renewSubscriptionPaymentMethodUrl" field', 'woographql-pro' )
							. ( $renew_subscription_payment_method_url_hardcoded ? __( ' This setting is disabled. The "RENEW_SUB_PAYMENT_URL_NONCE_PARAM" flag has been set with code', 'woographql-pro' ) : '' ),
						'type'              => 'text',
						'value'             => $renew_subscription_payment_method_url_hardcoded ? RENEW_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM : woographql_setting( 'renew_subscription_payment_method_url_nonce_param', '_wc_renew_sub' ),
						'disabled'          => defined( 'RENEW_SUBSCRIPTION_PAYMENT_URL_NONCE_PARAM' ) || ! in_array( 'renew_subscription_payment_method_url', $enabled_authorizing_url_fields, true ),
						'sanitize_callback' => static function ( $value ) {
							$other_nonces = CoreSettings::get_other_nonce_values( 'renew_subscription_payment_method_url' );
							if ( in_array( $value, $other_nonces, true ) ) {
								add_settings_error(
									'renew_subscription_payment_method_url_nonce_param',
									'unique',
									__( 'The <strong>Renew Subscription Payment Method URL nonce name</strong> field must be unique', 'woographql-pro' ),
									'error'
								);
		
								return '_wc_renew_sub';
							}
		
							return $value;
						},
					],
				]
			);
		}//end if

		$fields = array_merge(
			$fields,
			[
				[
					'name'    => 'pro_license',
					'label'   => __( 'Pro License', 'woographql-pro' ),
					'desc'    => $license_desc,
					'type'    => 'password',
					'default' => '',
				],
				[
					'name'     => 'bundle_products',
					'label'    => __( 'Enable Bundle Products', 'woographql-pro' ),
					'desc'     => ! defined( 'WOOGRAPHQL_PRO_TEST_MODE' )
						? __( 'If checked, Bundle Product types and mutations will be added to the schema. <strong>(WooCommerce Bundle Products must be installed and activated)</strong>', 'woographql-pro' )
						: $settings_status,
					'type'     => 'checkbox',
					'default'  => 'off',
					'value'    => $product_bundles_value,
					'disabled' => WooGraphQL_Pro::is_test_mode() || ! WooGraphQL_Pro::is_product_bundles_active(),
				],
				[
					'name'     => 'composite_products',
					'label'    => __( 'Enable Composite Products', 'woographql-pro' ),
					'desc'     => ! defined( 'WOOGRAPHQL_PRO_TEST_MODE' )
						? __( 'If checked, Composite Products types and mutations will be added to the schema. <strong>(Composite Products must be installed and activated)</strong>', 'woographql-pro' )
						: $settings_status,
					'type'     => 'checkbox',
					'default'  => 'off',
					'value'    => $composite_products_value,
					'disabled' => WooGraphQL_Pro::is_test_mode() || ! WooGraphQL_Pro::is_composite_products_active(),
				],
				[
					'name'     => 'product_addons',
					'label'    => __( 'Enable Product Add-ons', 'woographql-pro' ),
					'desc'     => ! defined( 'WOOGRAPHQL_PRO_TEST_MODE' )
						? __( 'If checked, Product Add-ons types and mutations will be added to the schema. <strong>(Product Add-ons must be installed and activated)</strong>', 'woographql-pro' )
						: $settings_status,
					'type'     => 'checkbox',
					'default'  => 'off',
					'value'    => $product_addons_value,
					'disabled' => WooGraphQL_Pro::is_test_mode() || ! WooGraphQL_Pro::is_product_addons_active(),
				],
				[
					'name'     => 'woo_subscriptions',
					'label'    => __( 'Enable Subscriptions', 'woographql-pro' ),
					'desc'     => ! defined( 'WOOGRAPHQL_PRO_TEST_MODE' )
						? __( 'If checked, WooCommerce Subscriptions types and mutations will be added to the schema. <strong>(WooCommerce Subscriptions must be installed and activated)</strong>', 'woographql-pro' )
						: $settings_status,
					'type'     => 'checkbox',
					'default'  => 'off',
					'value'    => $woo_subscriptions_value,
					'disabled' => WooGraphQL_Pro::is_test_mode() || ! WooGraphQL_Pro::is_subscriptions_active(),
				],
			]
		);

		return $fields;
	}
}
