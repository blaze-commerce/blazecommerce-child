<?php
/**
 * Mutation - Subscription_Change_Payment_Method
 *
 * Registers mutation for changing subscription payment method.
 *
 * @package WPGraphQL\WooCommerce\Pro\Mutation
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Mutation;

use Exception;
use GraphQL\Error\UserError;
use GraphQL\Type\Definition\ResolveInfo;
use WCS_Change_Payment_Method_Admin;
use WPGraphQL\AppContext;
use WPGraphQL\Utils\Utils;
use WPGraphQL\WooCommerce\Model\Order;

/**
 * Class - Subscription_Change_Payment_Method
 */
class Subscription_Change_Payment_Method {
	/**
	 * Registers mutation
	 */
	public static function register_mutation(): void {
		register_graphql_mutation(
			'changePaymentMethod',
			[
				'inputFields'         => self::get_input_fields(),
				'outputFields'        => self::get_output_fields(),
				'mutateAndGetPayload' => self::mutate_and_get_payload(),
			]
		);
	}

	/**
	 * Defines the mutation input field configuration
	 *
	 * @return array
	 */
	public static function get_input_fields() {
		return [
			'id'            => [
				'type'        => [ 'non_null' => 'ID' ],
				'description' => __( 'Subscription database ID or global ID', 'woographql-pro' ),
			],
			'paymentMethod' => [
				'type'        => [ 'non_null' => 'String' ],
				'description' => __( 'Payment method ID.', 'woographql-pro' ),
			],
			'postMeta'      => [
				'type'        => 'MetaDataInput',
				'description' => __( 'Payment method post meta and token', 'woographql-pro' ),
			],
			'userMeta'      => [
				'type'        => 'MetaDataInput',
				'description' => __( 'Payment method user meta and token', 'woographql-pro' ),
			],

		];
	}

	/**
	 * Defines the mutation output field configuration
	 *
	 * @return array
	 */
	public static function get_output_fields() {
		return [
			'subscription' => [
				'type'    => 'Subscription',
				'resolve' => static function ( $payload ) {
					$subscription = wcs_get_subscription( $payload['id'] );

					return false !== $subscription ? new Order( $subscription ) : null;
				},
			],
		];
	}

	/**
	 * Flatten meta data input in key:value pairs.
	 *
	 * @param array $meta_data_input  Meta data input array.
	 * @return array
	 */
	private static function flatten_meta( $meta_data_input = [] ) {
		$flattened_meta = [];
		foreach ( $meta_data_input as $input ) {
			$flattened_meta[ $input['key'] ] = $input['value'];
		}

		return $flattened_meta;
	}

	/**
	 * Defines the mutation data modification closure.
	 *
	 * @return callable
	 */
	public static function mutate_and_get_payload() {
		return static function ( $input, AppContext $context, ResolveInfo $info ) {
			if ( empty( $input['postMeta'] ) && empty( $input['userMeta'] ) ) {
				throw new UserError( __( 'No payment details provided', 'woographql-pro' ) );
			}

			if ( ! is_user_logged_in() ) {
				throw new UserError( __( 'Must be authenticated to reactivate a subscription', 'woographql-pro' ) );
			}

			$subscription_id = Utils::get_database_id_from_id( $input['id'] );
			if ( ! $subscription_id ) {
				throw new UserError( __( 'Subscription ID provided is invalid. Please check input and try again.', 'woographql-pro' ) );
			}

			$subscription = wcs_get_subscription( $subscription_id );
			if ( ! $subscription ) {
				throw new UserError( __( 'No subscription found connected to the provided Subscription ID.', 'woographql-pro' ) );
			}

			$is_owner = $subscription->get_customer_id() === get_current_user_id();
			$is_admin = wc_rest_check_post_permissions( 'shop_order', 'edit', $subscription_id );

			if ( ! $is_owner && ! $is_admin ) {
				throw new UserError( __( 'You do not have the permissions to reactivate this subscription', 'woographql-pro' ) );
			}

			$post_meta = [];
			$user_meta = [];
			if ( ! empty( $input['postMeta'] ) ) {
				$post_meta = self::flatten_meta( $input['postMeta'] );
			}
			if ( ! empty( $input['userMeta'] ) ) {
				$user_meta = self::flatten_meta( $input['userMeta'] );
			}

			$payment_details = compact( 'post_meta', 'user_meta' );
			$payment_method  = $input['paymentMethod'];
			try {
				if ( ! array_key_exists( $payment_method, WCS_Change_Payment_Method_Admin::get_valid_payment_methods( $subscription ) ) ) {
					// translators: placeholder is the payment method ID.
					throw new Exception( sprintf( __( 'The %s payment gateway does not support admin changing the payment method.', 'woographql-pro' ), $payment_method ) );
				}

				// Format the payment meta in the way payment gateways expect so it can be validated.
				$payment_method_meta = [];

				foreach ( $payment_details as $table => $meta ) {
					foreach ( $meta as $meta_key => $value ) {
						$payment_method_meta[ $table ][ $meta_key ] = [ 'value' => $value ];
					}
				}

				$subscription->set_payment_method( $payment_method, $payment_method_meta );
				$subscription_id = $subscription->save();

				return [ 'id' => $subscription_id ];
			} catch ( \Throwable $e ) {
				/* translators: 1$: gateway id, 2$: error message */
				throw new UserError( sprintf( __( 'Subscription payment method could not be set to %1$s with error message: %2$s', 'woographql-pro' ), $payment_method, $e->getMessage() ), 400 );
			}//end try
		};
	}
}
