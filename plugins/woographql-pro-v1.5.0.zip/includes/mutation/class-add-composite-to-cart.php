<?php
/**
 * Mutation - addCompositeToCart
 *
 * Registers mutation for adding a composite product to the cart.
 *
 * @package WPGraphQL\WooCommerce\Pro\Mutation
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Mutation;

use GraphQL\Error\UserError;
use GraphQL\Type\Definition\ResolveInfo;
use WPGraphQL\AppContext;
use WPGraphQL\WooCommerce\Data\Mutation\Cart_Mutation;

/**
 * Class - Add_Composite_To_Cart
 */
class Add_Composite_To_Cart {
	/**
	 * Registers mutation
	 */
	public static function register_mutation(): void {
		register_graphql_mutation(
			'addCompositeToCart',
			[
				'inputFields'         => self::get_input_fields(),
				'outputFields'        => self::get_output_fields(),
				'mutateAndGetPayload' => self::mutate_and_get_payload(),
			]
		);
	}

	/**
	 * Defines the mutation input field configuration
	 *
	 * @return array
	 */
	public static function get_input_fields() {
		return [
			'productId'     => [
				'type'        => [ 'non_null' => 'Int' ],
				'description' => 'Product ID of the bundle to add to the cart',
			],
			'quantity'      => [
				'type'        => 'Int',
				'description' => 'Quantity of the bundle',
			],
			'configuration' => [
				'type'        => [ 'list_of' => 'CompositeProductConfigurationInput' ],
				'description' => 'Composite configuration',
			],
			'extraData'     => [
				'type'        => 'String',
				'description' => 'JSON string representation of bundle item data',
			],
		];
	}

	/**
	 * Defines the mutation output field configuration
	 *
	 * @return array
	 */
	public static function get_output_fields() {
		return [
			'cartItem' => [
				'type'    => 'CompositeCartItem',
				'resolve' => static function ( $payload ) {
					return \WC()->cart->get_cart_item( $payload['key'] );
				},
			],
			'cart'     => Cart_Mutation::get_cart_field( true ),
		];
	}

	/**
	 * Defines the mutation data modification closure.
	 *
	 * @return callable
	 */
	public static function mutate_and_get_payload() {
		return static function ( $input, AppContext $context, ResolveInfo $info ) {
			Cart_Mutation::check_session_token();

			$cart_item_args = Cart_Mutation::prepare_cart_item( $input, $context, $info );

			// Add item to cart and get item key.
			$cart          = \WC_CP_Cart::instance();
			$cart_item_key = $cart->add_composite_to_cart(
				$cart_item_args[0],
				$cart_item_args[1],
				$cart_item_args['configuration'],
				$cart_item_args[4]
			);

			if ( empty( $cart_item_key ) ) {
				throw new UserError( 'Failed to add cart item. Please check input.' );
			}

			if ( is_wp_error( $cart_item_key ) ) {
				if ( $cart_item_key->error_data['woocommerce_composite_configuration']['notices'] ) {
					$notice = end( $cart_item_key->error_data['woocommerce_composite_configuration']['notices'] );

					// Bail if notice is not available.
					if ( empty( $notice['notice'] ) ) {
						throw new UserError( $cart_item_key->get_error_message() );
					}

					// There is not filterable way to alter the error message. Let's hack this instead.
					$message_offset = strpos( $notice['notice'], 'There is not enough stock ' );

					// Remove the wc_notice <a>cart</a> text. All we want is the product and stock values.
					if ( ! empty( $message_offset ) ) {
						throw new UserError( html_entity_decode( substr( $notice['notice'], $message_offset ) ) );
					}
				}

				throw new UserError( $cart_item_key->get_error_message() );
			}

			// Return payload.
			return [ 'key' => $cart_item_key ];
		};
	}
}
