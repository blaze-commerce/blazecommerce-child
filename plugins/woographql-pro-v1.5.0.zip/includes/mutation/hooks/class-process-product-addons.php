<?php
/**
 * Mutation Hook - graphql_woocommerce_new_cart_item_data
 *
 * Registers the "[ProductAddonInput]" type as the "addons" field to
 * all add-to-cart mutations input types and defines the callback for processing them.
 *
 * @package WPGraphQL\WooCommerce\Pro\Mutation
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Mutation\Hooks;

use GraphQL\Error\UserError;
use WPGraphQL\WooCommerce\Pro\WooGraphQL_Pro;

/**
 * Class - Process_Product_Addons
 */
class Process_Product_Addons {
	/**
	 * Process_Product_Addons constructor
	 *
	 * Registers "addons" fields and mutation process hooks.
	 */
	public static function register(): void {
		self::register_addons_fields();
		if ( WooGraphQL_Pro::is_composite_products_enabled() && WooGraphQL_Pro::is_composite_products_active() ) {
			self::register_composite_addons_fields();
		}

		add_filter( 'graphql_woocommerce_new_cart_item_data', [ self::class, 'process_addons_input' ], 10, 2 );
	}

	/**
	 * Loads a file from the product addons "includes" directory.
	 *
	 * @param string $file  File path.
	 * @return void
	 */
	private static function include_product_addons_file( string $file ) {
		include_once trailingslashit( WP_PLUGIN_DIR . '/woocommerce-product-addons/includes' ) . $file;
	}

	/**
	 * Register "addons" field to core WooGraphQL types.
	 *
	 * @return void
	 */
	private static function register_addons_fields() {
		register_graphql_field(
			'AddToCartInput',
			'addons',
			[
				'type'        => [ 'list_of' => 'ProductAddonInput' ],
				'description' => __( 'Product addons', 'woographql-pro' ),
			]
		);

		register_graphql_field(
			'CartItemInput',
			'addons',
			[
				'type'        => [ 'list_of' => 'ProductAddonInput' ],
				'description' => __( 'Product addons', 'woographql-pro' ),
			]
		);
	}

	/**
	 * Register "addons" field to the "AddCompositeToCartInput" type.
	 *
	 * @return void
	 */
	private static function register_composite_addons_fields() {
		register_graphql_field(
			'AddCompositeToCartInput',
			'addons',
			[
				'type'        => [ 'list_of' => 'ProductAddonInput' ],
				'description' => __( 'Product addons', 'woographql-pro' ),
			]
		);
	}

	/**
	 * If "addons" input provided, input is sanitize, validated, and added to "$cart_item_args".
	 *
	 * @param array $cart_item_args  Process cart item data to be added to the cart.
	 * @param array $input           Raw cart item input to be processed.
	 *
	 * @throws \GraphQL\Error\UserError  Invalid "addons" input provided.
	 *
	 * @return array
	 */
	public static function process_addons_input( $cart_item_args, $input ) {
		if ( ! empty( $input['addons'] ) ) {
			$post_data      = array_column( $input['addons'], 'value', 'fieldName' );
			$product_id     = $cart_item_args[0];
			$product_addons = \WC_Product_Addons_Helper::get_product_addons( $product_id );

			if ( empty( $cart_item_args[4]['addons'] ) ) {
				$cart_item_args[4]['addons'] = [];
			}

			if ( is_array( $product_addons ) && ! empty( $product_addons ) ) {
				self::include_product_addons_file( 'fields/abstract-wc-product-addons-field.php' );

				foreach ( $product_addons as $addon ) {
					// If type is heading, skip.
					if ( 'heading' === $addon['type'] ) {
						continue;
					}

					$value      = isset( $post_data[ $addon['field_name'] ] ) ? $post_data[ $addon['field_name'] ] : '';
					$list_types = [ 'checkbox', 'multiple_choice' ];
					if ( in_array( $addon['type'], $list_types, true ) ) {
						$value = array_map( 'sanitize_title', $value );
					}

					if ( ! in_array( $addon['type'], $list_types, true )
						|| ( 'multiple_choice' === $addon['type'] && 'radiobutton' !== $addon['display'] )
					) {
						$value = implode( ' ', $value );
					}

					switch ( $addon['type'] ) {
						case 'checkbox':
							self::include_product_addons_file( 'fields/class-wc-product-addons-field-list.php' );
							$field = new \WC_Product_Addons_Field_List( $addon, $value );
							break;
						case 'multiple_choice':
							switch ( $addon['display'] ) {
								case 'radiobutton':
									self::include_product_addons_file( 'fields/class-wc-product-addons-field-list.php' );
									$field = new \WC_Product_Addons_Field_List( $addon, $value );
									break;
								case 'images':
								case 'select':
									self::include_product_addons_file( 'fields/class-wc-product-addons-field-select.php' );
									$field = new \WC_Product_Addons_Field_Select( $addon, $value );
									break;
							}
							break;
						case 'custom_text':
						case 'custom_textarea':
						case 'custom_price':
						case 'input_multiplier':
							self::include_product_addons_file( 'fields/class-wc-product-addons-field-custom.php' );
							$field = new \WC_Product_Addons_Field_Custom( $addon, $value );
							break;
						case 'file_upload':
							self::include_product_addons_file( 'fields/class-wc-product-addons-field-file-upload.php' );
							$field = new \WC_Product_Addons_Field_File_Upload( $addon, $value );
							break;
					}//end switch
					
					if ( empty( $field ) ) {
						throw new UserError( __( 'Invalid addon type provided', 'woographql-pro' ) );
					}

					$data = $field->get_cart_item_data();

					if ( is_wp_error( $data ) ) {
						// Throw exception for add_to_cart to pickup.
						throw new UserError( $data->get_error_message() );
					} elseif ( $data ) {
						$cart_item_args[4]['addons'] = array_merge(
							$cart_item_args[4]['addons'],
							apply_filters(
								'woocommerce_product_addon_cart_item_data', // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
								$data,
								$addon,
								$product_id,
								$post_data
							)
						);
					}
				}//end foreach
			}//end if
		}//end if
		return $cart_item_args;
	}
}
