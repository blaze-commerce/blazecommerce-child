<?php
/**
 * Mutation Hook - graphql_woocommerce_new_cart_item_data
 *
 * Process the composite products configuration passed to the `addCompositeToCart` mutation
 *
 * @package WPGraphQL\WooCommerce\Pro\Mutation
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Mutation\Hooks;

use GraphQL\Error\UserError;
use GraphQL\Type\Definition\ResolveInfo;
use WC_Data_Store;
use WPGraphQL\AppContext;

/**
 * Class - Process_Composite_Configuration
 */
class Process_Composite_Configuration {
	/**
	 * Process_Composite_Configuration constructor
	 */
	public static function register(): void {
		add_filter( 'graphql_woocommerce_new_cart_item_data', [ self::class, 'process' ], 10, 4 );
	}

	/**
	 * Parses "configuration" input.
	 *
	 * @param array                                $cart_item_args  Cart item arguments.
	 * @param array                                $input           Raw mutation input.
	 * @param \WPGraphQL\AppContext                $context         AppContext instance.
	 * @param \GraphQL\Type\Definition\ResolveInfo $info            ResolveInfo instance.
	 *
	 * @throws \GraphQL\Error\UserError Invalid input.
	 *
	 * @return array
	 */
	public static function process( array $cart_item_args, array $input, AppContext $context, ResolveInfo $info ) {
		if ( 'addCompositeToCart' !== $info->fieldName ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			return $cart_item_args;
		}

		// Guard against invalid product types.
		$composite = ! empty( $input['productId'] ) ? wc_get_product( $input['productId'] ) : null;
		if ( empty( $composite ) ) {
			throw new UserError( __( 'No composite product provided', 'woographql-pro' ) );
		}

		if ( 'composite' !== $composite->get_type() ) {
			throw new UserError(
				sprintf(
					/* translators: Product type */
					__( 'Provided product ID must be connected to a "composite" product. %s is not valid type', 'woographql-pro' ),
					$composite->get_type()
				)
			);
		}

		/** @var \WC_Product_Composite $composite */

		// Guard against missing configuration.
		if ( empty( $input['configuration'] ) ) {
			throw new UserError( __( 'No composite configuration provided', 'woographql-pro' ) );
		}

		// Prepare configurations.
		$configuration_input = $input['configuration'];
		$configuration       = [];
		$components          = $composite->get_components();
		foreach ( $components as $component_id => $component ) {
			$component_index = array_search( $component->get_id(), array_column( $configuration_input, 'componentId' ), true );
			if ( false === $component_index ) {
				throw new UserError(
					sprintf(
						/* translators: Component name */
						__( 'Must include configuration for each component. The "%s" component was not provided a configuration', 'woographql-pro' ),
						$component->get_title()
					)
				);
			}
			$composited_product_id                = ! empty( $configuration_input[ $component_index ]['productId'] ) ? $configuration_input[ $component_index ]['productId'] : '';
			$composited_product_quantity          = isset( $configuration_input[ $component_index ]['quantity'] ) ? $configuration_input[ $component_index ]['quantity'] : $component->get_quantity( 'min' );
			$composited_product_sold_individually = false;

			$component_is_hidden = ! empty( $configuration_input[ $component_index ]['hidden'] ) && 'false' !== $configuration_input[ $component_index ]['hidden'];

			if ( ! $component_is_hidden ) {
				$component_option = $component->get_option( $composited_product_id );

				if ( ! $component_option ) {
					continue;
				}

				$composited_product                   = $component_option->get_product();
				$composited_product_type              = $composited_product->get_type();
				$composited_product_sold_individually = $composited_product->is_sold_individually();

				if ( $composited_product_sold_individually && $composited_product_quantity > 1 ) {
					$composited_product_quantity = 1;
				}
			}

			$configuration[ $component_id ]               = [];
			$configuration[ $component_id ]['product_id'] = $composited_product_id;
			$configuration[ $component_id ]['quantity']   = $composited_product_quantity;

			// Continue when selected product is 'Hidden'.
			if ( $component_is_hidden ) {
				continue;
			}

			if ( ! empty( $composited_product ) && ! empty( $composited_product_type ) && 'variable' === $composited_product_type ) {
				$variation_id = empty( $configuration_input[ $component_index ]['variationId'] ) ? '' : $configuration_input[ $component_index ]['variationId'];
				$attr_config  = empty( $configuration_input[ $component_index ]['variation'] ) ? [] : self::prepare_attributes( $composited_product_id, $configuration_input[ $component_index ]['variation'] );

				$configuration[ $component_id ]['attributes'] = $attr_config;

				// Store posted variation ID, or search for it.
				if ( $variation_id ) {
					$configuration[ $component_id ]['variation_id'] = $variation_id;
				} else {
					$variations = $composited_product->get_children();
					if ( count( $variations ) > 1 ) {
						/** @var \WC_Product_Data_Store_CPT $data_store */
						$data_store = WC_Data_Store::load( 'product' );

						if ( $variation_id === $data_store->find_matching_product_variation( $composited_product, $configuration[ $component_id ]['attributes'] ) ) {
							$configuration[ $component_id ]['variation_id'] = $variation_id;
						}
					} else {
						$configuration[ $component_id ]['variation_id'] = current( $variations );
					}
				}
			}//end if
		}//end foreach

		$cart = \WC_CP_Cart::instance();

		/**
		 * 'woocommerce_posted_composite_configuration' filter.
		 *
		 * @since  3.14.0
		 *
		 * @param  array                  $configuration
		 * @param  \WC_Product_Composite  $composite
		 */
		$cart_item_args['configuration'] = apply_filters(
			'woocommerce_posted_composite_configuration', // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			$cart->parse_composite_configuration( $composite, $configuration, true ),
			$composite
		);

		return $cart_item_args;
	}

	/**
	 * Processes the provided variation attributes data for the cart.
	 *
	 * @todo  Make equivalent function in WPGraphQL WooCommerce's "Cart_Mutation" class access public.
	 *
	 * @param int   $product_id      Product ID.
	 * @param array $variation_data  Variation data.
	 *
	 * @return array
	 *
	 * @throws \GraphQL\Error\UserError  Invalid cart attribute provided.
	 */
	public static function prepare_attributes( $product_id, array $variation_data = [] ) {
		$product = wc_get_product( $product_id );

		// Bail if bad product ID.
		if ( ! $product ) {
			throw new UserError(
				sprintf(
					/* translators: %s: product ID */
					__( 'No product found matching the ID provided: %s', 'woographql-pro' ),
					$product_id
				)
			);
		}

		$attribute_names = array_keys( $product->get_attributes() );

		$attributes = [];
		foreach ( $variation_data as $attribute ) {
			$attribute_name = $attribute['attributeName'];
			if ( in_array( "pa_{$attribute_name}", $attribute_names, true ) ) {
				$attribute_name = "pa_{$attribute_name}";
			} elseif ( ! in_array( $attribute_name, $attribute_names, true ) ) {
				throw new UserError(
					sprintf(
						/* translators: %1$s: attribute name, %2$s: product name */
						__( '%1$s is not a valid attribute of the product: %2$s.', 'woographql-pro' ),
						$attribute_name,
						$product->get_name()
					)
				);
			}

			$attribute_value = ! empty( $attribute['attributeValue'] ) ? $attribute['attributeValue'] : '';
			$attribute_key   = "attribute_{$attribute_name}";

			$attributes[ $attribute_key ] = $attribute_value;
		}

		return $attributes;
	}
}
