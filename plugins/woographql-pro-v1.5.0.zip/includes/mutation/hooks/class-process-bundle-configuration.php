<?php
/**
 * Mutation Hook - graphql_woocommerce_new_cart_item_data
 *
 * Process the product bundle configuration passed to the `addBundleToCart` mutation
 *
 * @package WPGraphQL\WooCommerce\Pro\Mutation
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Mutation\Hooks;

use GraphQL\Error\UserError;
use GraphQL\Type\Definition\ResolveInfo;
use WC_Data_Store;
use WPGraphQL\AppContext;

/**
 * Class - Process_Bundle_Configuration
 */
class Process_Bundle_Configuration {
	/**
	 * Process_Bundle_Configuration constructor
	 */
	public static function register(): void {
		add_filter( 'graphql_woocommerce_new_cart_item_data', [ self::class, 'process' ], 10, 4 );
	}

	/**
	 * Parses "bundleItems" input.
	 *
	 * @param array                                $cart_item_args  Cart item arguments.
	 * @param array                                $input           Raw mutation input.
	 * @param \WPGraphQL\AppContext                $context         AppContext instance.
	 * @param \GraphQL\Type\Definition\ResolveInfo $info            ResolveInfo instance.
	 *
	 * @throws \GraphQL\Error\UserError Invalid input.
	 *
	 * @return array
	 */
	public static function process( array $cart_item_args, array $input, AppContext $context, ResolveInfo $info ) {
		if ( 'addBundleToCart' !== $info->fieldName ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			return $cart_item_args;
		}

		$configuration = [];

		// Guard against invalid product types.
		$product = ! empty( $input['productId'] ) ? wc_get_product( $input['productId'] ) : null;

		if ( ! $product ) {
			throw new UserError(
				sprintf(
					/* translators: Product ID */
					__( 'Provided product ID %s does not exist.', 'woographql-pro' ),
					$input['productId']
				)
			);
		}

		if ( 'bundle' !== $product->get_type() ) {
			throw new UserError(
				sprintf(
					/* translators: Product type */
					__( 'Provided product ID must be connected to a "bundle" product. %s is not valid type', 'woographql-pro' ),
					$product->get_type()
				)
			);
		}

		/** @var \WC_Product_Bundle $product */

		$product_id    = $product->get_id();
		$bundled_items = $product->get_bundled_items();
		$posted_config = [];

		if ( ! empty( $bundled_items ) ) {

			// Guard against missing bundle items.
			if ( empty( $input['bundleItems'] ) ) {
				throw new UserError(
					__( 'No bundle items provided. Connected item details must be included when adding a bundle items to the cart.', 'woographql-pro' )
				);
			}

			$posted_data = [];
			// Get and mapped bundle items by product ID.
			foreach ( $input['bundleItems'] as $bundled_item ) {
				$item_id                 = $bundled_item['bundleItemId'];
				$posted_data[ $item_id ] = [];

				if ( isset( $bundled_item['quantity'] ) ) {
					$posted_data[ $item_id ]['quantity'] = $bundled_item['quantity'];
				}

				if ( ! empty( $bundled_item['variationId'] ) ) {
					$posted_data[ $item_id ]['variation_id'] = $bundled_item['variationId'];
				}

				if ( ! empty( $bundled_item['variation'] ) ) {
					$posted_data[ $item_id ]['variation'] = array_column( $bundled_item['variation'], 'attributeValue', 'attributeName' );
				}

				if ( isset( $bundled_item['optionalSelected'] ) ) {
					$posted_data[ $item_id ]['optional_selected'] = \wc_bool_to_string( $bundled_item['optionalSelected'] );
				}
			}

			foreach ( $bundled_items as $bundled_item_id => $bundled_item ) {
				$posted_config[ $bundled_item_id ] = [];

				$bundled_product_id   = $bundled_item->get_product_id();
				$bundled_product_type = $bundled_item->product->get_type();
				$is_optional          = $bundled_item->is_optional();

				$bundled_product_qty = isset( $posted_data[ $bundled_item_id ]['quantity'] ) ? $posted_data[ $bundled_item_id ]['quantity'] : $bundled_item->get_quantity( 'default' );

				$posted_config[ $bundled_item_id ]['product_id'] = $bundled_product_id;

				if ( $bundled_item->has_title_override() ) {
					$posted_config[ $bundled_item_id ]['title'] = $bundled_item->get_raw_title();
				}

				if ( $is_optional ) {
					$posted_config[ $bundled_item_id ]['optional_selected'] = isset( $posted_data[ $bundled_item_id ]['optional_selected'] )
						? $posted_data[ $bundled_item_id ]['optional_selected']
						: 'no';

					if ( 'no' === $posted_config[ $bundled_item_id ]['optional_selected'] ) {
						$bundled_product_qty = 0;
					}
				}

				$posted_config[ $bundled_item_id ]['quantity'] = $bundled_product_qty;

				// Store variable product configuration in stamp to avoid generating the same bundle cart id.
				if ( 'variable' === $bundled_product_type || 'variable-subscription' === $bundled_product_type ) {
					$attributes = $bundled_item->product->get_attributes();
					$variations = $bundled_item->get_children();
					$attr_stamp = [];

					// Store posted attribute values.
					foreach ( $attributes as $attribute ) {
						if ( ! $attribute->get_variation() ) {
							continue;
						}

						$attribute_name = $attribute->get_name();
						$taxonomy       = str_replace( 'pa_', '', wc_variation_attribute_name( $attribute_name ) );

						// Get value from post data.
						if ( ! empty( $posted_data[ $bundled_item_id ]['variation'][ $taxonomy ] ) ) {
							if ( $attribute->is_taxonomy() ) {
								$value = sanitize_title( stripslashes( $posted_data[ $bundled_item_id ]['variation'][ $taxonomy ] ) );
							} else {
								/** @var string $sanitized_value */
								$sanitized_value = wc_clean( stripslashes( $posted_data[ $bundled_item_id ]['variation'][ $taxonomy ] ) );
								$value           = html_entity_decode( $sanitized_value, ENT_QUOTES, get_bloginfo( 'charset' ) );
							}

							$attr_stamp[ $taxonomy ] = $value;

							// Value pre-selected?
						} else {
							$configurable_variation_attributes  = $bundled_item->get_product_variation_attributes( true );
							$selected_variation_attribute_value = $bundled_item->get_selected_product_variation_attribute( $attribute_name );

							if ( ! isset( $configurable_variation_attributes[ $attribute_name ] ) && '' !== $selected_variation_attribute_value ) {
								if ( $attribute->is_taxonomy() ) {
									foreach ( $attribute->get_terms() as $option ) {
										if ( sanitize_title( $selected_variation_attribute_value ) === $option->slug ) {
											$attr_stamp[ $taxonomy ] = $option->slug;
											break;
										}
									}
								} else {
									foreach ( $attribute->get_options() as $option ) {
										if ( sanitize_title( $selected_variation_attribute_value ) === $selected_variation_attribute_value ) {
											$found = sanitize_title( $option ) === $selected_variation_attribute_value;
										} else {
											$found = $selected_variation_attribute_value === $option;
										}

										if ( $found ) {
											$attr_stamp[ $taxonomy ] = $option;
											break;
										}
									}
								}//end if
							}//end if
						}//end if
					}//end foreach

					$posted_config[ $bundled_item_id ]['attributes'] = $attr_stamp;

					// Store posted variation ID, or search for it.
					if ( count( $variations ) > 1 ) {
						if ( ! empty( $posted_data[ $bundled_item_id ]['variation_id'] ) ) {
							$posted_config[ $bundled_item_id ]['variation_id'] = $posted_data[ $bundled_item_id ]['variation_id'];
						} else {
							/** @var \WC_Product_Data_Store_CPT $data_store */
							$data_store = WC_Data_Store::load( 'product' );

							$found_variation_id = $data_store->find_matching_product_variation( $bundled_item->get_product(), $posted_config[ $bundled_item_id ]['attributes'] );
							if ( $found_variation_id ) {
								$posted_config[ $bundled_item_id ]['variation_id'] = $found_variation_id;
							}
						}
					} else {
						$posted_config[ $bundled_item_id ]['variation_id'] = current( $variations );
					}
				}//end if
			}//end foreach
		}//end if

		$cart = \WC_PB_Cart::instance();

		/**
		 * 'woocommerce_posted_bundle_configuration' filter.
		 *
		 * @since  3.14.0
		 *
		 * @param  array               $configuration
		 * @param  \WC_Product_Bundle  $bundle
		 */
		$cart_item_args['configuration'] = apply_filters(
			'woocommerce_posted_bundle_configuration', // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			$cart->parse_bundle_configuration( $product, $posted_config, true ),
			$product
		);

		return $cart_item_args;
	}
}
