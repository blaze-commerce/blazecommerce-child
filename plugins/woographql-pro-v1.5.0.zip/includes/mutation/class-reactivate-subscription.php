<?php
/**
 * Mutation - reactivateSubscription
 *
 * Registers mutation for reactivating a subscription.
 *
 * @package WPGraphQL\WooCommerce\Pro\Mutation
 * @since 1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Mutation;

use GraphQL\Error\UserError;
use GraphQL\Type\Definition\ResolveInfo;
use WPGraphQL\AppContext;
use WPGraphQL\Utils\Utils;
use WPGraphQL\WooCommerce\Model\Order;

/**
 * Class - Reactivate_Subscription
 */
class Reactivate_Subscription {
	/**
	 * Registers mutation
	 */
	public static function register_mutation(): void {
		register_graphql_mutation(
			'reactivateSubscription',
			[
				'inputFields'         => self::get_input_fields(),
				'outputFields'        => self::get_output_fields(),
				'mutateAndGetPayload' => self::mutate_and_get_payload(),
			]
		);
	}

	/**
	 * Defines the mutation input field configuration
	 *
	 * @return array
	 */
	public static function get_input_fields() {
		return [
			'id' => [
				'type'        => [ 'non_null' => 'ID' ],
				'description' => __( 'Subscription database ID or global ID', 'woographql-pro' ),
			],
		];
	}

	/**
	 * Defines the mutation output field configuration
	 *
	 * @return array
	 */
	public static function get_output_fields() {
		return [
			'subscription' => [
				'type'    => 'Subscription',
				'resolve' => static function ( $payload ) {
					$subscription = wcs_get_subscription( $payload['id'] );

					return false !== $subscription ? new Order( $subscription ) : null;
				},
			],
		];
	}

	/**
	 * Defines the mutation data modification closure.
	 *
	 * @return callable
	 */
	public static function mutate_and_get_payload() {
		return static function ( $input, AppContext $context, ResolveInfo $info ) {
			if ( ! is_user_logged_in() ) {
				throw new UserError( __( 'Must be authenticated to reactivate a subscription', 'woographql-pro' ) );
			}

			$subscription_id = Utils::get_database_id_from_id( $input['id'] );
			if ( ! $subscription_id ) {
				throw new UserError( __( 'Subscription ID provided is invalid. Please check input and try again.', 'woographql-pro' ) );
			}

			$subscription = wcs_get_subscription( $subscription_id );
			if ( ! $subscription ) {
				throw new UserError( __( 'No subscription found connected to the provided Subscription ID.', 'woographql-pro' ) );
			}

			$is_owner = $subscription->get_customer_id() === get_current_user_id();
			$is_admin = wc_rest_check_post_permissions( 'shop_order', 'edit', $subscription_id );

			if ( ! $is_owner && ! $is_admin ) {
				throw new UserError( __( 'You do not have the permissions to reactivate this subscription', 'woographql-pro' ) );
			}

			if ( 'active' === $subscription->get_status() ) {
				throw new UserError( __( 'Subscription already active', 'woographql-pro' ) );
			}

			if ( $subscription->needs_payment() ) {
				throw new UserError( __( 'This subscription can not be reactivated until a payment is made for renewal.', 'woographql-pro' ) );
			}

			// Process to reactivating subscription.
			$user_type = $is_owner ? 'subscriber' : 'administrator';
			$subscription->update_status( 'active' );
			$subscription->add_order_note(
				sprintf(
					/* translators: User role */
					_x(
						'Subscription reactivated by the %s via GraphQL.',
						'order note left on subscription after user action',
						'woographql-pro'
					),
					$user_type
				)
			);
			return [ 'id' => $subscription_id ];
		};
	}
}
