<?php
/**
 * Enum Type - ProductAddonShortTextRestrictionEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Product_Addon_Short_Text_Restriction_Enum
 */
class Product_Addon_Short_Text_Restriction_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'ProductAddonShortTextRestrictionEnum',
			[
				'description' => __( 'Short text addon input type restrictions.', 'woographql-pro' ),
				'values'      => [
					'ANY_TEXT'                 => [ 'value' => 'any_text' ],
					'ONLY_LETTERS'             => [ 'value' => 'only_letters' ],
					'ONLY_NUMBERS'             => [ 'value' => 'only_numbers' ],
					'ONLY_LETTERS_AND_NUMBERS' => [ 'value' => 'only_letters_numbers' ],
					'EMAIL'                    => [ 'value' => 'email' ],
				],
			]
		);
	}
}
