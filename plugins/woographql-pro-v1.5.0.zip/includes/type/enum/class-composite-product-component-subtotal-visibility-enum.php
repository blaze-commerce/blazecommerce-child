<?php
/**
 * Enum Type - CompositeProductComponentSubtotalVisibilityEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Component_Subtotal_Visibility_Enum
 */
class Composite_Product_Component_Subtotal_Visibility_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductComponentSubtotalVisibilityEnum',
			[
				'description' => __( 'Locations the composite product component option subtotal can be displayed.', 'woographql-pro' ),
				'values'      => [
					'SINGLE_PRODUCT_SUMMARY' => [ 'value' => 'show_subtotal_product' ],
					'CART_AND_CHECKOUT'      => [ 'value' => 'show_subtotal_cart' ],
					'ORDER_DETAILS'          => [ 'value' => 'show_subtotal_orders' ],
				],
			]
		);
	}
}
