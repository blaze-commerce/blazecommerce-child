<?php
/**
 * Enum Type - ProductAddonPriceAdjustEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Product_Addon_Price_Adjust_Enum
 */
class Product_Addon_Price_Adjust_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'ProductAddonPriceAdjustEnum',
			[
				'description' => __( 'Methods to calculate add-on price adjustments.', 'woographql-pro' ),
				'values'      => [
					'FLAT_FEE'         => [ 'value' => 'flat_fee' ],
					'QUANTITY_BASED'   => [ 'value' => 'quantity_based' ],
					'PERCENTAGE_BASED' => [ 'value' => 'percentage_based' ],
				],
			]
		);
	}
}
