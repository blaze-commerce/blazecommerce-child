<?php
/**
 * Enum Type - CompositeProductComponentPaginationStyleEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Component_Pagination_Style_Enum
 */
class Composite_Product_Component_Pagination_Style_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductComponentPaginationStyleEnum',
			[
				'description' => __( 'Composite product component option types.', 'woographql-pro' ),
				'values'      => [
					'CLASSIC'   => [
						'value'       => 'classic',
						'description' => __( 'Component Options are arranged in pages, similar to the main shop loop.', 'woographql-pro' ),
					],
					'LOAD_MORE' => [
						'value'       => 'load-more',
						'description' => __( 'Component Options are appended by clicking a "Load more" button.', 'woographql-pro' ),
					],
				],
			]
		);
	}
}
