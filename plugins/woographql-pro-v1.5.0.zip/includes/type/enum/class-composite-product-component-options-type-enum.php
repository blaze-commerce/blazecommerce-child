<?php
/**
 * Enum Type - CompositeProductComponentOptionsTypeEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Component_Options_Type_Enum
 */
class Composite_Product_Component_Options_Type_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductComponentOptionsTypeEnum',
			[
				'description' => __( 'Composite product component option types.', 'woographql-pro' ),
				'values'      => [
					'SELECT_PRODUCTS'   => [ 'value' => 'product_ids' ],
					'SELECT_CATEGORIES' => [ 'value' => 'category_ids' ],
				],
			]
		);
	}
}
