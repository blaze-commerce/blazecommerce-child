<?php
/**
 * Enum Type - ProductAddonTitleFormatEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Product_Addon_Title_Format_Enum
 */
class Product_Addon_Title_Format_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'ProductAddonTitleFormatEnum',
			[
				'description' => __( 'Product addon title display formats', 'woographql-pro' ),
				'values'      => [
					'LABEL'   => [ 'value' => 'label' ],
					'HEADING' => [ 'value' => 'heading' ],
					'HIDE'    => [ 'value' => 'hide' ],
				],
			]
		);
	}
}
