<?php
/**
 * Enum Type - CompositeProductScenarioConditionCompareEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Scenario_Condition_Compare_Enum
 */
class Composite_Product_Scenario_Condition_Compare_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductScenarioConditionCompareEnum',
			[
				'description' => __( 'Composite product scenario condition compare options.', 'woographql-pro' ),
				'values'      => [
					'IS'     => [ 'value' => 'in' ],
					'IS_NOT' => [ 'value' => 'not-in' ],
					'IS_ANY' => [ 'value' => 'in-any' ],
				],
			]
		);
	}
}
