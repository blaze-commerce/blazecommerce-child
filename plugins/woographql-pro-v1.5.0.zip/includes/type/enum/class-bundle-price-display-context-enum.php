<?php
/**
 * Enum Type - BundlePriceDisplayContextEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Bundle_Price_Display_Context_Enum
 */
class Bundle_Price_Display_Context_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'BundlePriceDisplayContextEnum',
			[
				'description' => __( 'WC Subscriptions query display context', 'woographql-pro' ),
				'values'      => [
					'RAW'     => [ 'value' => 'raw' ],
					'DEFAULT' => [ 'value' => 'default' ],
				],
			]
		);
	}
}
