<?php
/**
 * Enum Type - CompositeProductComponentOptionStyleEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Component_Option_Style_Enum
 */
class Composite_Product_Component_Option_Style_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductComponentOptionStyleEnum',
			[
				'description' => __( 'Composite product component option UI styles', 'woographql-pro' ),
				'values'      => [
					'DROPDOWN'      => [ 'value' => 'dropdowns' ],
					'THUMBNAILS'    => [ 'value' => 'thumbnails' ],
					'RADIO_BUTTONS' => [ 'value' => 'radios' ],
				],
			]
		);
	}
}
