<?php
/**
 * Enum Type - SubscriptionPriceDisplayContextEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Subscription_Price_Display_Context_Enum
 */
class Subscription_Price_Display_Context_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'SubscriptionPriceDisplayContextEnum',
			[
				'description' => __( 'WC Subscriptions query display context', 'woographql-pro' ),
				'values'      => [
					'RAW'     => [ 'value' => 'raw' ],
					'HTML'    => [ 'value' => 'html' ],
					'DEFAULT' => [ 'value' => 'default' ],
				],
			]
		);
	}
}
