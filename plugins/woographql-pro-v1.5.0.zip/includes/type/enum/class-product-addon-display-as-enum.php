<?php
/**
 * Enum Type - ProductAddonDisplayAsEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Product_Addon_Display_As_Enum
 */
class Product_Addon_Display_As_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'ProductAddonDisplayAsEnum',
			[
				'description' => __( 'UI types for Multiple choice add-on.', 'woographql-pro' ),
				'values'      => [
					'DROPDOWNS' => [ 'value' => 'select' ],
					'RADIO'     => [ 'value' => 'radio' ],
					'IMAGES'    => [ 'value' => 'images' ],
				],
			]
		);
	}
}
