<?php
/**
 * Enum Type - CompositeProductComponentSelectionDetailVisibilityEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Component_Selection_Detail_Visibility_Enum
 */
class Composite_Product_Component_Selection_Detail_Visibility_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductComponentSelectionDetailVisibilityEnum',
			[
				'description' => __( 'Composite product component option details.', 'woographql-pro' ),
				'values'      => [
					'HIDE_TITLE'       => [ 'value' => 'hide_product_title' ],
					'HIDE_DESCRIPTION' => [ 'value' => 'hide_product_description' ],
					'HIDE_THUMBNAIL'   => [ 'value' => 'hide_product_thumbnail' ],
					'HIDE_PRICE'       => [ 'value' => 'hide_product_price' ],
					'DISABLE_ADDONS'   => [ 'value' => 'disable_addons' ],
				],
			]
		);
	}
}
