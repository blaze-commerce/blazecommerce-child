<?php
/**
 * Enum Type - CompositeProductShopPriceCalcOptions
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Shop_Price_Calc_Options
 */
class Composite_Product_Shop_Price_Calc_Options {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductShopPriceCalcOptions',
			[
				'description' => __( 'Composite product methods for display the price.', 'woographql-pro' ),
				'values'      => [
					'USE_DEFAULTS'      => [ 'value' => 'defaults' ],
					'CALCULATE_FROM_TO' => [ 'value' => 'min_max' ],
					'HIDE'              => [ 'value' => 'hidden' ],
				],
			]
		);
	}
}
