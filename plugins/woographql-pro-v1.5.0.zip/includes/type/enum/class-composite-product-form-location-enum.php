<?php
/**
 * Enum Type - CompositeProductFormLocationEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Form_Location_Enum
 */
class Composite_Product_Form_Location_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductFormLocationEnum',
			[
				'description' => __( 'Composite product add-to-cart locations', 'woographql-pro' ),
				'values'      => [
					'DEFAULT'     => [ 'value' => 'default' ],
					'BEFORE_TABS' => [ 'value' => 'after_summary' ],
				],
			]
		);
	}
}
