<?php
/**
 * Enum Type - CompositeProductComponentOptionSelectActionEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Component_Option_Select_Action_Enum
 */
class Composite_Product_Component_Option_Select_Action_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductComponentOptionSelectActionEnum',
			[
				'description' => __( 'Composite product component on-option-selection actions', 'woographql-pro' ),
				'values'      => [
					'VIEW_SELECTION_DETAILS' => [ 'value' => 'view' ],
					'VIEW_NEXT_STEP'         => [ 'value' => 'transition' ],
				],
			]
		);
	}
}
