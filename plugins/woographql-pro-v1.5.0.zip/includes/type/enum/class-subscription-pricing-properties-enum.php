<?php
/**
 * Enum Type - PricingPropertiesEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Subscription_Pricing_Properties_Enum
 */
class Subscription_Pricing_Properties_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'SubscriptionPricingPropertiesEnum',
			[
				'description' => __( 'Properties that make up the subscription price', 'woographql-pro' ),
				'values'      => [
					'SUBSCRIPTION_PRICE'  => [ 'value' => 'subscription_price' ],
					'SUBSCRIPTION_PERIOD' => [ 'value' => 'subscription_period' ],
					'SUBSCRIPTION_LENGTH' => [ 'value' => 'subscription_length' ],
					'SIGN_UP_FEE'         => [ 'value' => 'sign_up_fee' ],
					'TRAIL_LENGTH'        => [ 'value' => 'trial_length' ],
				],
			]
		);
	}
}
