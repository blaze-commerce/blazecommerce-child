<?php
/**
 * Enum Type - ProductBundleMinMaxEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Product_Bundle_Min_Max_Enum
 */
class Product_Bundle_Min_Max_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'ProductBundleMinMaxEnum',
			[
				'description' => __( 'Minimum or maximum enumeration.', 'woographql-pro' ),
				'values'      => [
					'MIN' => [ 'value' => 'min' ],
					'MAX' => [ 'value' => 'max' ],
				],
			]
		);
	}
}
