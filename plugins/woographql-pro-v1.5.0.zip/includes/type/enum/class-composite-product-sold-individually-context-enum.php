<?php
/**
 * Enum Type - CompositeProductSoldIndividuallyContextEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Composite_Product_Sold_Individually_Context_Enum
 */
class Composite_Product_Sold_Individually_Context_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_enum_type(
			'CompositeProductSoldIndividuallyContextEnum',
			[
				'description' => __( 'Composite product sold individually context enum.', 'woographql-pro' ),
				'values'      => [
					'CONFIGURATION' => [ 'value' => 'configuration' ],
					'PRODUCT'       => [ 'value' => 'product' ],
				],
			]
		);
	}
}
