<?php
/**
 * Enum Type - ProductAddonFieldEnum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

use WPGraphQL\WooCommerce\Pro\Product_Addons_Filters;

/**
 * Class Product_Addon_Field_Enum
 */
class Product_Addon_Field_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		$values = [];
		foreach ( Product_Addons_Filters::get_enabled_addon_types() as $value => $type_name ) {
			$replaced_type_name = preg_replace( '/\B([A-Z])/', '_$1', str_replace( 'Addon', '', $type_name ) );
			$label              = ! empty( $replaced_type_name ) ? strtoupper( $replaced_type_name ) : null;

			if ( empty( $label ) ) {
				graphql_debug(
					sprintf(
						// translators: %s is the type name.
						__( 'Cannot parse enum values for %s', 'woographql-pro' ),
						$type_name
					)
				);

				continue;
			}

			$values[ $label ] = [ 'value' => $value ];
		}

		register_graphql_enum_type(
			'ProductAddonFieldEnum',
			[
				'description' => __( 'UI types for Multiple choice add-on.', 'woographql-pro' ),
				'values'      => $values,
			]
		);
	}
}
