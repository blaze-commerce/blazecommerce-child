<?php
/**
 * Enum Type - Subscription_Statuses_Enum
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPEnum
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPEnum;

/**
 * Class Subscription_Statuses_Enum
 */
class Subscription_Statuses_Enum {
	/**
	 * Registers type
	 */
	public static function register(): void {
		$statuses = \wcs_get_subscription_statuses();

		$values = [];
		foreach ( $statuses as $status => $description ) {
			$value          = str_replace( 'wc-', '', $status );
			$key            = strtoupper( str_replace( '-', '_', $value ) );
			$values[ $key ] = compact( 'value', 'description' );
		}

		register_graphql_enum_type(
			'SubscriptionStatusesEnum',
			[
				'description' => __( 'Valid subscription statuses', 'woographql-pro' ),
				'values'      => $values,
			]
		);
	}
}
