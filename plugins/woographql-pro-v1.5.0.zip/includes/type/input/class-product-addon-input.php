<?php
/**
 * WPInputObjectType - ProductAddonInput
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPInputObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPInputObject;

/**
 * Class Product_Addon_Input
 */
class Product_Addon_Input {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_input_type(
			'ProductAddonInput',
			[
				'description' => __( 'Product addon type', 'woographql-pro' ),
				'fields'      => [
					'fieldName' => [
						'type'        => [ 'non_null' => 'String' ],
						'description' => __( 'Addon name', 'woographql-pro' ),
					],
					'value'     => [
						'type'        => [ 'list_of' => 'String' ],
						'description' => __( 'Addon value', 'woographql-pro' ),
					],
				],
			]
		);
	}
}
