<?php
/**
 * WPInputObjectType - BundleItemInput
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPInputObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPInputObject;

/**
 * Class Bundle_Item_Input
 */
class Bundle_Item_Input {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_input_type(
			'BundleItemInput',
			[
				'description' => __( 'Cart item quantity', 'woographql-pro' ),
				'fields'      => [
					'bundleItemId'     => [
						'type'        => [ 'non_null' => 'Int' ],
						'description' => __( 'Bundle item database ID or global ID', 'woographql-pro' ),
					],
					'quantity'         => [
						'type'        => 'Int',
						'description' => __( 'Bundle item quantity', 'woographql-pro' ),
					],
					'variationId'      => [
						'type'        => 'Int',
						'description' => __( 'Bundle item product variation database ID or global ID', 'woographql-pro' ),
					],
					'variation'        => [
						'type'        => [ 'list_of' => 'ProductAttributeInput' ],
						'description' => __( 'Bundle item product variation attributes', 'woographql-pro' ),
					],
					'optionalSelected' => [
						'type'        => 'Boolean',
						'description' => __( 'Has this optional bundle item been selected?', 'woographql-pro' ),
					],
				],
			]
		);
	}
}
