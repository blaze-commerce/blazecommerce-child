<?php
/**
 * WPInputObjectType - CompositeProductConfigurationInput
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPInputObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPInputObject;

/**
 * Class Composite_Product_Configuration_Input
 */
class Composite_Product_Configuration_Input {
	/**
	 * Registers type
	 */
	public static function register(): void {
		register_graphql_input_type(
			'CompositeProductConfigurationInput',
			[
				'description' => __( 'Cart item quantity', 'woographql-pro' ),
				'fields'      => [
					'componentId' => [
						'type'        => [ 'non_null' => 'ID' ],
						'description' => __( 'Composite component ID', 'woographql-pro' ),
					],
					'productId'   => [
						'type'        => 'Int',
						'description' => __( 'Cart item product database ID or global ID', 'woographql-pro' ),
					],
					'quantity'    => [
						'type'        => 'Int',
						'description' => __( 'Cart item quantity', 'woographql-pro' ),
					],
					'variationId' => [
						'type'        => 'Int',
						'description' => __( 'Cart item product variation database ID or global ID', 'woographql-pro' ),
					],
					'variation'   => [
						'type'        => [ 'list_of' => 'ProductAttributeInput' ],
						'description' => __( 'Cart item product variation attributes', 'woographql-pro' ),
					],
					'hidden'      => [
						'type'        => 'Boolean',
						'description' => __( 'Is component hidden and to be bypassed?', 'woographql-pro' ),
					],
				],
			]
		);
	}
}
