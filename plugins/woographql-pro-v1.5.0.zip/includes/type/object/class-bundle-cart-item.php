<?php
/**
 * Object Type - Cart item types
 *
 * Registers the BundleCartItem type to the GraphQL schema.
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

use WPGraphQL\WooCommerce\Type\WPInterface\Cart_Item;

/**
 * Class Bundle_Cart_Item
 */
class Bundle_Cart_Item {
	/**
	 * Registers type and queries to GraphQL Schema.
	 */
	public static function register(): void {
		register_graphql_field(
			'CartToCartItemConnectionWhereArgs',
			'hideBundled',
			[
				'type'        => 'Boolean',
				'description' => __( 'hide products bundled in bundle product', 'woographql-pro' ),
			]
		);
		add_filter(
			'graphql_cart_item_connection_query_args',
			static function ( $query_args, $source, $args, $context, $info ) {
				$where_args = ! empty( $args['where'] ) ? $args['where'] : [];
				if ( isset( $where_args['hideBundled'] ) ) {
					$hide_bundled            = $where_args['hideBundled'];
					$query_args['filters'][] = static function ( $cart_item ) use ( $hide_bundled ) {
						$is_bundled = isset( $cart_item['bundled_item_id'] );
						return $hide_bundled ? ! $is_bundled : true;
					};
				}

				return $query_args;
			},
			10,
			5
		);

		register_graphql_object_type(
			'BundleCartItem',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'Composite cart item object.', 'woographql-pro' ),
				'interfaces'      => [ 'CartItem', 'Node' ],
				'fields'          => array_merge(
					[
						'bundledItems' => [
							'type'        => [ 'list_of' => 'BundledItem' ],
							'description' => __( 'Bundled items', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								if ( ! empty( $source['stamp'] ) ) {
									$bundled_items = $source['stamp'];
									array_walk(
										$bundled_items,
										static function ( &$bundle_item, $bundle_item_id ) {
											$bundle_item['id'] = $bundle_item_id;
										}
									);
									return array_values( $bundled_items );
								}

								return [];
							},
						],
					]
				),
			]
		);

		register_graphql_object_type(
			'BundledItem',
			[

				'eagerlyLoadType' => true,
				'description'     => __( 'Composite cart item object.', 'woographql-pro' ),
				'fields'          => [
					'bundleItemId'     => [
						'type'        => [ 'non_null' => 'Int' ],
						'description' => __( 'Item quantity in cart.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return isset( $source['id'] ) ? absint( $source['id'] ) : 0;
						},
					],
					'quantity'         => [
						'type'        => 'Integer',
						'description' => __( 'Item quantity in cart.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return isset( $source['quantity'] ) ? absint( $source['quantity'] ) : 0;
						},
					],
					'discount'         => [
						'type'        => 'Float',
						'description' => __( 'Discount on item.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['discount'] ) ? $source['discount'] : null;
						},
					],
					'optionalSelected' => [
						'type'        => 'Boolean',
						'description' => __( 'Is component optionally selected', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return isset( $source['optional_selected'] )
								? $source['optional_selected']
								: null;
						},
					],
				],
				'connections'     => Cart_Item::get_connections(),
			]
		);
	}
}
