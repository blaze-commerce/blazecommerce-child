<?php
/**
 * Object Type - Product types
 *
 * Registers product types
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

use WPGraphQL\Data\Connection\PostObjectConnectionResolver;
use WPGraphQL\WooCommerce\Connection\Products;
use WPGraphQL\WooCommerce\Data\Connection\Product_Connection_Resolver;
use WPGraphQL\WooCommerce\Model\Product as Product_Model;
use WPGraphQL\WooCommerce\Type\WPObject\Product_Types;
use WPGraphQL\WooCommerce\WP_GraphQL_WooCommerce as WooGraphQL;


/**
 * Class Bundle_Product
 */
class Bundle_Product {
	/**
	 * Registers product types to the WPGraphQL schema
	 */
	public static function register(): void {
		self::set_product_model_fields();
		self::register_type();
		self::register_bundle_item_edge_connections();
	}

	/**
	 * Attaches bundled item data object one edges between BundleProduct => Product.
	 *
	 * @param array $edge  Product connection edge connected to bundled item.
	 * @return \WC_Bundled_Item_Data|false
	 */
	public static function get_bundled_item_for_edge( $edge ) {
		$source = ! empty( $edge['source'] ) ? $edge['source'] : null;
		$node   = ! empty( $edge['node'] ) ? $edge['node'] : null;

		// Bail early if the source isnt a bundle or the node isnt a product.
		if ( ! $source instanceof Product_Model || 'bundle' !== $source->type || ! $node instanceof Product_Model ) {
			return false;
		}

		$bundled_data_items = wp_cache_get( 'BUNDLED_ITEMS_' . $source->ID );
		if ( false === $bundled_data_items ) {
			$bundled_data_items = $source->get_bundled_data_items(); // @phpstan-ignore-line
			wp_cache_set( 'BUNDLED_ITEMS_' . $source->ID, $bundled_data_items );
		}

		$raw_bundled_data_item = array_filter(
			$bundled_data_items,
			static function ( \WC_Bundled_Item_Data $item ) use ( $node ) {
				return $item->get_product_id() === $node->ID;
			}
		);
		if ( empty( $raw_bundled_data_item ) ) {
			return false;
		}
		
		return \WC_PB_DB::get_bundled_item( array_pop( $raw_bundled_data_item )->get_bundled_item_id() );
	}

	/**
	 * Adds filters for setting the necessary fields on the model.
	 *
	 * @return void
	 */
	public static function set_product_model_fields() {
		add_filter( 'graphql_bundle_product_model_use_pricing_and_tax_fields', '__return_true' );
		add_filter( 'graphql_bundle_product_model_use_inventory_fields', '__return_true' );
		add_filter( 'graphql_bundle_product_model_use_virtual_data_fields', '__return_true' );
		add_filter( 'graphql_bundle_product_model_use_variation_pricing_fields', '__return_false' );
		add_filter( 'graphql_bundle_product_model_use_external_fields', '__return_false' );
		add_filter( 'graphql_bundle_product_model_use_grouped_fields', '__return_false' );
	}

	/**
	 * Returns fields related to product bundles
	 *
	 * @return array
	 */
	public static function get_type_fields() {
		return [
			'price'                 => [
				'type'        => 'String',
				'args'        => [
					'minOrMax' => [
						'type'        => 'ProductBundleMinMaxEnum',
						'description' => __( 'How should price be format? Defaults to simple string', 'woographql-pro' ),
					],
				],
				'description' => __( 'Bundle price', 'woographql-pro' ),
				'resolve'     => static function ( $source, $args ) {
					$min_or_max = ! empty( $args['minOrMax'] ) ? $args['minOrMax'] : 'min';

					$bundle_price = $source->get_bundle_price( $min_or_max );

					return ! empty( $bundle_price ) ? wc_graphql_price( $bundle_price ) : null;
				},
			],
			'regularPrice'          => [
				'type'        => 'String',
				'args'        => [
					'minOrMax' => [
						'type'        => 'ProductBundleMinMaxEnum',
						'description' => __( 'How should price be format? Defaults to simple string', 'woographql-pro' ),
					],
				],
				'description' => __( 'Bundle price', 'woographql-pro' ),
				'resolve'     => static function ( $source, $args ) {
					$min_or_max = ! empty( $args['minOrMax'] ) ? $args['minOrMax'] : 'min';

					$bundle_price = $source->get_bundle_regular_price( $min_or_max );

					return ! empty( $bundle_price ) ? wc_graphql_price( $bundle_price ) : null;
				},
			],
			'minBundleSize'         => [
				'type'        => 'Integer',
				'description' => __( 'Min bundle size', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					$min_bundle_size = $source->get_min_bundle_size();

					return ! empty( $min_bundle_size ) ? absint( $min_bundle_size ) : 0;
				},
			],
			'maxBundleSize'         => [
				'type'        => 'Integer',
				'description' => __( 'Max bundle size', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					$max_bundle_size = $source->get_max_bundle_size();

					return ! empty( $max_bundle_size ) ? absint( $max_bundle_size ) : null;
				},
			],
			'layout'                => [
				'type'        => 'String',
				'description' => __( 'Layout option state', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					$layout = $source->get_layout();

					return ! empty( $layout ) ? $layout : null;
				},
			],
			'groupMode'             => [
				'type'        => 'String',
				'description' => __( 'Item grouping option state', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					$group_mode = $source->get_group_mode();

					return ! empty( $group_mode ) ? $group_mode : null;
				},
			],
			'addToCartFormLocation' => [
				'type'        => 'String',
				'description' => __( 'Form location option state', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					$add_to_cart_form_location = $source->get_add_to_cart_form_location();

					return ! empty( $add_to_cart_form_location ) ? $add_to_cart_form_location : null;
				},
			],
			'editableInCart'        => [
				'type'        => 'Boolean',
				'description' => __( 'Whether the bundle is editable in the cart.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_editable_in_cart();
				},
			],
		];
	}

	/**
	 * Get the edge fields for the bundle item
	 *
	 * @return array[]
	 */
	public static function get_edge_fields() {
		return [
			'quantityMin'                        => [
				'type'        => 'Int',
				'description' => __( 'The quantity minimum', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$minimum = $bundled_item->get_meta( 'quantity_min' );

					return ! empty( $minimum ) ? $minimum : null;
				},
			],
			'quantityMax'                        => [
				'type'        => 'Int',
				'description' => __( 'The quantity maximum', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$maximum = $bundled_item->get_meta( 'quantity_max' );

					return ! empty( $maximum ) ? $maximum : null;
				},
			],
			'bundledItemId'                      => [
				'type'        => 'Int',
				'description' => __( 'The bundled item ID', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$bundled_item_id = $bundled_item->get_bundled_item_id();

					return ! empty( $bundled_item_id ) ? $bundled_item_id : null;
				},
			],
			'menuOrder'                          => [
				'type'        => 'Int',
				'description' => __( 'Bundled item menu order', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$menu_order = $bundled_item->get_menu_order();

					return ! empty( $menu_order ) ? $menu_order : null;
				},
			],
			'pricedIndividually'                 => [
				'type'        => 'Boolean',
				'description' => __( 'Whether the price of the bundled item is added to the price of the parent bundle product.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'priced_individually' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'shippedIndividually'                => [
				'type'        => 'Boolean',
				'description' => __( 'Whether the bundled item is shipped individually.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'shipped_individually' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'overrideTitle'                      => [
				'type'        => 'Boolean',
				'description' => __( 'Whether to override the bundled item title.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'override_title' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'title'                              => [
				'type'        => 'String',
				'description' => __( 'The overwritten title.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$title = $bundled_item->get_meta( 'title' );

					return ! empty( $title ) ? $title : null;
				},
			],
			'overrideDescription'                => [
				'type'        => 'Boolean',
				'description' => __( 'Whether to override the bundled item description.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'override_description' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'description'                        => [
				'type'        => 'String',
				'description' => __( 'The overwritten description.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$description = $bundled_item->get_meta( 'description' );

					return ! empty( $description ) ? $description : null;
				},
			],
			'optional'                           => [
				'type'        => 'Boolean',
				'description' => __( 'Whether the bundled item is optional.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'optional' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'hideThumbnail'                      => [
				'type'        => 'Boolean',
				'description' => __( 'Whether to hide the thumbnail.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'hide_thumbnail' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'discount'                           => [
				'type'        => 'String',
				'description' => __( 'Bundle item discount if priced individually.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$discount = $bundled_item->get_meta( 'discount' );

					return ! empty( $discount ) ? $discount : null;
				},
			],
			'overrideVariations'                 => [
				'type'        => 'Boolean',
				'description' => __( 'Whether the bundle item overrides the variations.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'override_variations' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'overrideDefaultVariationAttributes' => [
				'type'        => 'Boolean',
				'description' => __( 'Whether the bundled item overrides the default attributes.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$result = $bundled_item->get_meta( 'override_default_variation_attributes' );

					return empty( $result ) ? null : 'yes' === $result;
				},
			],
			'defaultVariationAttributes'         => [
				'type'        => [ 'list_of' => 'VariationAttribute' ],
				'description' => __( 'The default variation attributes.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$attributes      = [];
					$attributes_meta = $bundled_item->get_meta( 'default_variation_attributes' );
					if ( ! empty( $attributes_meta ) ) {
						$pa_taxonomies = WooGraphQL::get_product_attribute_taxonomies();
						$attributes    = array_map(
							static function ( $key, $value ) use ( $pa_taxonomies ) {
								$attribute = [
									'name'        => $key,
									'value'       => ! empty( $value ) ? $value : null,
									'is_taxonomy' => in_array( $key, $pa_taxonomies, true ),
								];

								return $attribute;
							},
							array_keys( $attributes_meta ),
							$attributes_meta
						);
					}

					return $attributes;
				},
			],
			'singleProductVisibility'            => [
				'type'        => 'String',
				'description' => __( 'Whether the bundle item is visible on the product page', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$single_product_visibility = $bundled_item->get_meta( 'single_product_visibility' );

					return ! empty( $single_product_visibility ) ? $single_product_visibility : null;
				},
			],
			'cartVisibility'                     => [
				'type'        => 'String',
				'description' => __( 'Whether the bundle item is visible on the cart page', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$cart_visibility = $bundled_item->get_meta( 'cart_visibility' );

					return ! empty( $cart_visibility ) ? $cart_visibility : null;
				},
			],
			'orderVisibility'                    => [
				'type'        => 'String',
				'description' => __( 'Whether the bundle item is visible on the order page', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$order_visibility = $bundled_item->get_meta( 'order_visibility' );

					return ! empty( $order_visibility ) ? $order_visibility : null;
				},
			],
			'singleProductPriceVisibility'       => [
				'type'        => 'String',
				'description' => __( 'Whether the bundle item price is visible on the product page', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$product_price_visibility = $bundled_item->get_meta( 'single_product_price_visibility' );

					return ! empty( $product_price_visibility ) ? $product_price_visibility : null;
				},
			],
			'cartPriceVisibility'                => [
				'type'        => 'String',
				'description' => __( 'Whether the bundle item price is visible on the cart page', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$cart_price_visibility = $bundled_item->get_meta( 'cart_price_visibility' );

					return ! empty( $cart_price_visibility ) ? $cart_price_visibility : null;
				},
			],
			'orderPriceVisibility'               => [
				'type'        => 'String',
				'description' => __( 'Whether the bundle item price is visible on the order page', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( empty( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) ) {
						return null;
					}

					$order_price_visibility = $bundled_item->get_meta( 'order_price_visibility' );

					return ! empty( $order_price_visibility ) ? $order_price_visibility : null;
				},
			],
		];
	}

	/**
	 * Register connections on the BundleItem connection edge
	 */
	public static function register_bundle_item_edge_connections(): void {
		register_graphql_connection(
			[
				'eagerlyLoadType' => true,
				'fromType'        => 'BundleProductToProductConnectionEdge',
				'toType'          => 'ProductVariation',
				'fromFieldName'   => 'allowedVariations',
				'connectionArgs'  => Products::get_connection_args(),
				'resolve'         => static function ( $source, $args, $context, $info ) {
					$resolver = new Product_Connection_Resolver( $source, $args, $context, $info );

					$resolver->set_query_arg( 'post_parent', $source['node']->ID );
					$resolver->set_query_arg( 'post_type', 'product_variation' );

					$variation_ids = [];
					/**
					 * Bundle item data.
					 *
					 * @var \WC_Bundled_Item_Data $bundled_item
					 */
					$bundled_item = self::get_bundled_item_for_edge( $source );

					if ( is_a( $bundled_item, \WC_Bundled_Item_Data::class ) ) {
						$allowed_variations = $bundled_item->get_meta( 'allowed_variations' );
						$variation_ids      = ! empty( $allowed_variations )
							? array_map( 'absint', $allowed_variations )
							: [];
					}

					$resolver->set_query_arg( 'post__in', $variation_ids );

					return $resolver->get_connection();
				},
			]
		);
	}

	/**
	 * Registers "BundleProduct" type.
	 */
	private static function register_type(): void {
		register_graphql_object_type(
			'BundleProduct',
			[
				'description' => __( 'A product bundle object', 'woographql-pro' ),
				'interfaces'  => Product_Types::get_product_interfaces(
					[
						'InventoriedProduct',
						'ProductWithDimensions',
						'ProductWithPricing',
					]
				),
				'fields'      => self::get_type_fields(),
				'connections' => [
					'bundleItems' => [
						'toType'     => 'Product',
						'queryClass' => '\WC_Product_Query',
						'resolve'    => static function ( $source, $args, $context, $info ) {
							$resolver = new PostObjectConnectionResolver( $source, $args, $context, $info, 'product' );

							$args        = [
								'bundle_id' => $source->ID,
								'return'    => 'id=>product_id',
								'order_by'  => [ 'menu_order' => 'ASC' ],
							];
							$product_ids = \WC_PB_DB::query_bundled_items( $args );

							// Only get the bundle items that belong to this product.
							$resolver->set_query_arg( 'post__in', $product_ids );

							return $resolver->get_connection();
						},
						'edgeFields' => self::get_edge_fields(),
					],
				],
			]
		);
	}
}
