<?php
/**
 * Object Type - Product types
 *
 * Registers the CompositeProduct type and queries to the GraphQL schema.
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

use GraphQLRelay\Relay;
use WPGraphQL\AppContext;
use WPGraphQL\Model\Taxonomy;
use WPGraphQL\WooCommerce\Type\WPObject\Product_Types;

/**
 * Class Composite_Product
 */
class Composite_Product {
	/**
	 * Registers type and queries to GraphQL Schema.
	 */
	public static function register(): void {
		self::set_product_model_fields();
		self::register_type();
		self::register_composite_product_component_type();
		self::register_composite_product_scenario_type();
	}

	/**
	 * Adds filters for setting the necessary fields on the model.
	 *
	 * @return void
	 */
	public static function set_product_model_fields() {
		add_filter( 'graphql_bundle_product_model_use_pricing_and_tax_fields', '__return_true' );
		add_filter( 'graphql_bundle_product_model_use_inventory_fields', '__return_true' );
		add_filter( 'graphql_bundle_product_model_use_virtual_data_fields', '__return_true' );
		add_filter( 'graphql_bundle_product_model_use_variation_pricing_fields', '__return_false' );
		add_filter( 'graphql_bundle_product_model_use_external_fields', '__return_false' );
		add_filter( 'graphql_bundle_product_model_use_grouped_fields', '__return_false' );
	}

	/**
	 * Returns fields related to composite products
	 *
	 * @return array
	 */
	public static function get_type_fields() {
		return [
			'layout'                  => [
				'type'        => 'CompositeProductLayoutEnum',
				'description' => __( 'Single-product template layout. Applicable to composite-type products.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_layout();
				},
			],
			'addToCartFormLocation'   => [
				'type'        => 'CompositeProductFormLocationEnum',
				'description' => __( 'Controls the form location of the product in the single-product page. Applicable to composite-type products.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_add_to_cart_form_location();
				},
			],
			'shopPriceCalculation'    => [
				'type'        => 'CompositeProductShopPriceCalcOptions',
				'description' => __( 'Composite catalog price calculation. Applicable to composite-type products.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_shop_price_calc();
				},
			],
			'editableInCart'          => [
				'type'        => 'Boolean',
				'description' => __( 'Controls whether the configuration of this product can be modified from the cart page. Applicable to composite-type products.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_editable_in_cart();
				},
			],
			'virtualComposite'        => [
				'type'        => 'Boolean',
				'description' => __( 'Forces all contents of this composite to be treated as virtual.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_virtual_composite();
				},
			],
			'soldIndividuallyContext' => [
				'type'        => 'CompositeProductSoldIndividuallyContextEnum',
				'description' => __( 'Sold Individually option context. Applicable to composite-type products.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_sold_individually_context();
				},
			],
			'components'              => [
				'type'        => [ 'list_of' => 'CompositeProductComponent' ],
				'description' => __( 'List of components that this product consists of. Applicable to composite-type products.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return $source->get_components();
				},
			],
			'scenarios'               => [
				'type'        => [ 'list_of' => 'CompositeProductScenario' ],
				'description' => __( 'Scenarios data. Applicable to composite-type products.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					$scenarios = $source->get_scenario_data();
					array_walk(
						$scenarios,
						static function ( &$scenario, $id ) use ( $source ) {
							$scenario['id']         = $id;
							$scenario['product_id'] = $source->ID;
							return $scenario;
						}
					);

					return $scenarios;
				},
			],
		];
	}

	/**
	 * Registers "BundleProduct" type.
	 */
	private static function register_type(): void {
		register_graphql_object_type(
			'CompositeProduct',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'A composite product object', 'woographql-pro' ),
				'interfaces'      => Product_Types::get_product_interfaces(
					[
						'InventoriedProduct',
						'ProductWithPricing',
						'ProductWithDimensions',
					]
				),
				'fields'          => self::get_type_fields(),
			]
		);
	}

	/**
	 * Registers "CompositeProductComponent" type.
	 *
	 * @return void
	 */
	public static function register_composite_product_component_type() {
		register_graphql_object_type(
			'CompositeProductComponent',
			[
				'description' => __( 'A component of a composite product', 'woographql-pro' ),
				'interfaces'  => [ 'Node' ],
				'fields'      => [
					'id'                        => [
						'type'        => [ 'non_null' => 'ID' ],
						'description' => __( 'Component global unique identifier.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return Relay::toGlobalId( 'composite_component', $source->get_id() );
						},
					],
					'componentId'               => [
						'type'        => [ 'non_null' => 'Integer' ],
						'description' => __( 'Component ID.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_id();
						},
					],
					'title'                     => [
						'type'        => 'String',
						'description' => __( 'Title of the component.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_title();
						},
					],
					'slug'                      => [
						'type'        => 'String',
						'description' => __( 'Slug of the component.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_slug();
						},
					],
					'description'               => [
						'type'        => 'String',
						'args'        => [
							'format' => [
								'type'        => 'PostObjectFieldFormatEnum',
								'description' => __( 'Format of the description.', 'woographql-pro' ),
							],
						],
						'description' => __( 'Description of the component.', 'woographql-pro' ),
						'resolve'     => static function ( $source, array $args ) {
							$description = ! empty( $source->get_description() ) ? $source->get_description() : null;
							if ( empty( $description ) ) {
								return null;
							}
							if ( isset( $args['format'] ) && 'raw' === $args['format'] ) {
								$description = wp_strip_all_tags( $description );
							}
							return $description;
						},
					],
					'queryType'                 => [
						'type'        => 'CompositeProductComponentOptionsTypeEnum',
						'description' => __( 'Component options type. Either "Products" or "Categories"', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source['query_type'];
						},
					],
					'queryOptions'              => [
						'type'        => [ 'list_of' => 'Product' ],
						'description' => __( 'The available options for this component. Either a list of product or product category.', 'woographql-pro' ),
						'resolve'     => static function ( $source, $args, AppContext $context ) {
							$ids     = $source->get_options();
							$options = [];
							foreach ( $ids as $id ) {
								$options[] = $context->get_loader( 'wc_post' )->load_deferred( $id );
							}

							return $options;
						},
					],
					'optional'                  => [
						'type'        => 'Boolean',
						'description' => __( 'Indicates whether the component is optional.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->is_optional();
						},
					],
					'defaultOption'             => [
						'type'        => 'Product',
						'description' => __( 'The default option selected', 'woographql-pro' ),
						'resolve'     => static function ( $source, $args, AppContext $context ) {
							$id = $source->get_default_option();
							if ( empty( $id ) ) {
								return null;
							}

							return $context->get_loader( 'wc_post' )->load_deferred( $id );
						},
					],
					'thumbnail'                 => [
						'type'        => 'MediaItem',
						'description' => __( 'Thumbnail associated with this Component.', 'woographql-pro' ),
						'resolve'     => static function ( $source, $args, AppContext $context ) {
							$data = $source->get_data();
							if ( empty( $data['thumbnail_id'] ) ) {
								return null;
							}
							return $context->get_loader( 'post' )->load_deferred( $data['thumbnail_id'] );
						},
					],
					'optionsStyle'              => [
						'type'        => 'CompositeProductComponentOptionStyleEnum',
						'description' => __( 'Indicates which template to use for displaying component options.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_options_style();
						},
					],
					'paginationStyle'           => [
						'type'        => 'CompositeProductComponentPaginationStyleEnum',
						'description' => __( 'Controls how new Thumbnails are loaded into the Component Options view. Applicable when the Options Style of this Component is set to Thumbnails.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_pagination_style();
						},
					],
					'discount'                  => [
						'type'        => 'String',
						'description' => __( 'Discount applied to the component, applicable when Priced Individually is enabled.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source->get_discount() ) ? $source->get_discount() : null;
						},
					],
					'minQuantity'               => [
						'type'        => 'Integer',
						'description' => __( 'Minimum component quantity.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_quantity( 'min' );
						},
					],
					'maxQuantity'               => [
						'type'        => 'Integer',
						'description' => __( 'Maximum component quantity.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_quantity( 'max' );
						},
					],
					'pricedIndividually'        => [
						'type'        => 'Boolean',
						'description' => __( 'Indicates whether the price of this component is added to the base price of the composite.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->is_priced_individually();
						},
					],
					'shippedIndividually'       => [
						'type'        => 'Boolean',
						'description' => __( 'Indicates whether this component is shipped separately from the composite.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->is_shipped_individually();
						},
					],
					'optionsSelectAction'       => [
						'type'        => 'CompositeProductComponentOptionSelectActionEnum',
						'description' => __( 'Action to be executed upon option selection.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->get_select_action();
						},
					],
					'showSortingOptions'        => [
						'type'        => 'Boolean',
						'description' => __( 'Whether to display sorting options in this Component.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->show_sorting_options();
						},
					],
					'showFilteringOptions'      => [
						'type'        => 'Boolean',
						'description' => __( 'Whether to display filtering options in this Component.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source->show_filtering_options();
						},
					],
					'attributeFilters'          => [
						'type'        => [ 'list_of' => 'Taxonomy' ],
						'description' => __( 'Attribute to use for creating Component Option filters.', 'woographql-pro' ),
						'resolve'     => static function ( $source, $args, AppContext $context ) {
							$taxonomies           = [];
							$taxonomy_ids         = $source->get_attribute_filters();
							$attribute_taxonomies = wc_get_attribute_taxonomies();
							$allowed_taxonomies   = \WPGraphQL::get_allowed_taxonomies( 'objects' );

							foreach ( $attribute_taxonomies as $tax ) {
								$tax_slug = 'pa_' . $tax->attribute_name;
								if ( in_array( absint( $tax->attribute_id ), $taxonomy_ids, true ) && isset( $allowed_taxonomies[ $tax_slug ] ) ) {
									$taxonomies[] = new Taxonomy( $allowed_taxonomies[ $tax_slug ] );
								}
							}

							return $taxonomies;
						},
					],
					'selectionDetailVisibility' => [
						'type'        => [ 'list_of' => 'CompositeProductComponentSelectionDetailVisibilityEnum' ],
						'description' => __( 'The component details to display for this component.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							$detail_visibility = [];
							if ( $source->hide_selected_option_title() ) {
								$detail_visibility[] = 'hide_product_title';
							}
							if ( $source->hide_selected_option_description() ) {
								$detail_visibility[] = 'hide_product_description';
							}
							if ( $source->hide_selected_option_thumbnail() ) {
								$detail_visibility[] = 'hide_product_thumbnail';
							}
							if ( $source->hide_selected_option_price() ) {
								$detail_visibility[] = 'hide_product_price';
							}
							if ( $source->disable_addons() ) {
								$detail_visibility[] = 'disable_addons';
							}

							return $detail_visibility;
						},
					],
					'subtotalVisibility'        => [
						'type'        => [ 'list_of' => 'CompositeProductComponentSubtotalVisibilityEnum' ],
						'description' => __( 'Locations of where this components subtotal should be visible.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							$subtotal_visibility = [];
							if ( $source->is_subtotal_visible( 'product ' ) ) {
								$subtotal_visibility[] = 'show_subtotal_product';
							}
							if ( $source->is_subtotal_visible( 'cart' ) ) {
								$subtotal_visibility[] = 'show_subtotal_cart';
							}
							if ( $source->is_subtotal_visible( 'orders' ) ) {
								$subtotal_visibility[] = 'show_subtotal_orders';
							}

							return $subtotal_visibility;
						},
					],
				],
			]
		);
	}

	/**
	 * Register Composite product scenario type and sub-types.
	 *
	 * @return void
	 */
	public static function register_composite_product_scenario_type() {
		register_graphql_object_type(
			'CompositeProductScenario',
			[
				'description' => __( 'A component of a composite product', 'woographql-pro' ),
				'interfaces'  => [ 'Node' ],
				'fields'      => [
					'id'            => [
						'type'        => [ 'non_null' => 'ID' ],
						'description' => __( 'Scenario Unique Identifier.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return Relay::toGlobalId( 'composite_scenario', $source['id'] );
						},
					],
					'scenarioId'    => [
						'type'        => [ 'non_null' => 'String' ],
						'description' => __( 'Scenario ID.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source['id'];
						},
					],
					'name'          => [
						'type'        => 'String',
						'description' => __( 'Name of the scenario.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source['title'];
						},
					],
					'description'   => [
						'type'        => 'String',
						'description' => __( 'Optional short description of the scenario.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source['description'];
						},
					],
					'enabled'       => [
						'type'        => 'Boolean',
						'description' => __( 'Controls whether the Scenario will be enabled or disabled.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return wc_string_to_bool( $source['enabled'] );
						},
					],
					'configuration' => [
						'type'        => [ 'list_of' => 'CompositeProductScenarioConfiguration' ],
						'description' => __( 'Scenario matching conditions.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							$configurations = [];
							$component_ids  = array_keys( $source['component_data'] );
							foreach ( $component_ids as $component_id ) {
								if ( 'masked' === $source['modifier'][ $component_id ] ) {
									continue;
								}
								$configurations[] = [
									'component_id'      => $component_id,
									'component_options' => array_filter( $source['component_data'][ $component_id ] ),
									'options_modifier'  => $source['modifier'][ $component_id ],
									'product_id'        => $source['product_id'],
								];
							}
							return $configurations;
						},
					],
					'actions'       => [
						'type'        => [ 'list_of' => 'CompositeProductScenarioAction' ],
						'description' => __( 'Scenario actions.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							$actions    = [];
							$action_ids = array_keys( $source['scenario_actions'] );
							foreach ( $action_ids as $action_id ) {
								if ( 'compat_group' === $action_id ) {
									continue;
								}
								$new_action = [
									'action_id'  => $action_id,
									'is_active'  => $source['scenario_actions'][ $action_id ]['is_active'],
									'product_id' => $source['product_id'],
								];
								if ( 'conditional_components' === $action_id ) {
									$new_action['hidden_components'] = $source['scenario_actions'][ $action_id ]['hidden_components'];
								}

								if ( 'conditional_options' === $action_id ) {
									$component_ids                = array_keys( $source['scenario_actions'][ $action_id ]['component_data'] );
									$new_action['hidden_options'] = [];
									foreach ( $component_ids as $component_id ) {
										if ( 'masked' === $source['scenario_actions'][ $action_id ]['modifier'][ $component_id ] ) {
											continue;
										}
										$new_action['hidden_options'][] = [
											'product_id'   => $source['product_id'],
											'component_id' => $component_id,
											'component_options' => $source['scenario_actions'][ $action_id ]['component_data'][ $component_id ],
											'options_modifier' => $source['scenario_actions'][ $action_id ]['modifier'][ $component_id ],
										];
									}
								}

								$actions[] = $new_action;
							}//end foreach
							return $actions;
						},
					],
				],
			]
		);

		register_graphql_object_type(
			'CompositeProductScenarioConfiguration',
			[
				'description' => __( 'Composite product scenario condition object', 'woographql-pro' ),
				'fields'      => [
					'component'        => [
						'type'        => 'CompositeProductComponent',
						'description' => __( 'Composite product component the scenario is observing.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							/** @var \WC_Product_Composite|null|false $product */
							$product = ! empty( $source['product_id'] ) ? wc_get_product( $source['product_id'] ) : null;

							return ! empty( $product ) ? $product->get_component( $source['component_id'] ) : null;
						},
					],
					'componentOptions' => [
						'type'        => [ 'list_of' => 'Product' ],
						'description' => __( 'Composite product component selection the scenario is observing', 'woographql-pro' ),
						'resolve'     => static function ( $source, $args, AppContext $context ) {
							$option_ids = array_map( 'absint', $source['component_options'] );
							$product    = wc_get_product( $source['product_id'] );
							$options    = [];
							foreach ( $option_ids as $id ) {
								if ( empty( $id ) ) {
									return null;
								}

								$options[] = $context->get_loader( 'wc_post' )->load_deferred( $id );
							}

							return $options;
						},
					],
					'optionsModifier'  => [
						'type'        => 'CompositeProductScenarioConditionCompareEnum',
						'description' => __( 'The desired relation between the target component and target selection', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source['options_modifier'];
						},
					],
				],
			]
		);

		register_graphql_object_type(
			'CompositeProductScenarioAction',
			[
				'description' => __( 'Composite product scenario action object', 'woographql-pro' ),
				'fields'      => [
					'actionId'         => [
						'type'        => [ 'non_null' => 'String' ],
						'description' => __( 'Scenario action ID.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source['action_id'];
						},
					],
					'isActive'         => [
						'type'        => 'Boolean',
						'description' => __( 'Indicates whether the scenario action is active.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return $source['is_active'];
						},
					],
					'hiddenComponents' => [
						'type'        => [ 'list_of' => 'CompositeProductComponent' ],
						'description' => __( 'Components to hide.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							if ( empty( $source['hidden_components'] ) || empty( $source['product_id'] ) ) {
								return [];
							}

							/** @var \WC_Product_Composite $product */
							$product = wc_get_product( $source['product_id'] ) ?: null;

							if ( empty( $product ) ) {
								return [];
							}

							$component_ids = array_map( 'absint', $source['hidden_components'] );

							return array_map(
								static function ( $component_id ) use ( $product ) {
									return $product->get_component( (string) $component_id );
								},
								$component_ids
							);
						},
					],
					'hiddenOptions'    => [
						'type'        => [ 'list_of' => 'CompositeProductScenarioConfiguration' ],
						'description' => __( 'Component options to hide.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ( ! empty( $source['hidden_options'] ) && is_array( $source['hidden_options'] ) )
								? $source['hidden_options']
								: [];
						},
					],
				],
			]
		);
	}
}
