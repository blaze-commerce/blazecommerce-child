<?php
/**
 * Object Type - Cart item types
 *
 * Registers the CompositeCartItem type to the GraphQL schema.
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

use WPGraphQL\WooCommerce\Type\WPInterface\Cart_Item;

/**
 * Class Composite_Cart_Item
 */
class Composite_Cart_Item {
	/**
	 * Registers type and queries to GraphQL Schema.
	 */
	public static function register(): void {
		register_graphql_field(
			'CartToCartItemConnectionWhereArgs',
			'hideCompositeChildren',
			[
				'type'        => 'Boolean',
				'description' => __( 'hide products included as components of composite products.', 'woographql-pro' ),
			]
		);
		add_filter(
			'graphql_cart_item_connection_query_args',
			static function ( $query_args, $source, $args, $context, $info ) {
				$where_args = ! empty( $args['where'] ) ? $args['where'] : [];
				if ( isset( $where_args['hideCompositeChildren'] ) ) {
					$hide_components         = $where_args['hideCompositeChildren'];
					$query_args['filters'][] = static function ( $cart_item ) use ( $hide_components ) {
						$is_component = isset( $cart_item['composite_parent'] );
						return $hide_components ? ! $is_component : true;
					};
				}

				return $query_args;
			},
			10,
			5
		);
		register_graphql_object_type(
			'CompositeCartItem',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'Composite cart item object.', 'woographql-pro' ),
				'interfaces'      => [ 'CartItem', 'Node' ],
				'fields'          => array_merge(
					[
						'components' => [
							'type'        => [ 'list_of' => 'CompositeCartItemCompositeData' ],
							'description' => __( 'Composite product components', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								foreach ( $source['composite_data'] as $component_id => &$composite_data ) {
									$composite_data['component_id'] = $component_id;
								}

								return array_values( $source['composite_data'] );
							},
						],
						'children'   => [
							'type'        => [ 'list_of' => 'Product' ],
							'description' => __( 'Composite product components', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return null;
							},
						],
					]
				),
			]
		);

		register_graphql_object_type(
			'CompositeCartItemCompositeData',
			[
				'description' => __( 'Composite cart item object.', 'woographql-pro' ),
				'fields'      => [
					'productId' => [
						'type'        => 'Int',
						'description' => __( 'Composite product components', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['product_id'] ) ? absint( $source['product_id'] ) : null;
						},
					],
					'component' => [
						'type'        => 'CompositeProductComponent',
						'description' => __( 'Composite product components', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							/** @var \WC_Product_Composite|null|false $product */
							$product = ! empty( $source['composite_id'] ) ? wc_get_product( $source['composite_id'] ) : null;

							return ! empty( $product ) ? $product->get_component( $source['component_id'] ) : null;
						},
					],
					'quantity'  => [
						'type'        => 'Integer',
						'description' => __( 'Quantity of component in cart', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return absint( $source['quantity'] );
						},
					],
				],
				'connections' => Cart_Item::get_connections(),
			]
		);
	}
}
