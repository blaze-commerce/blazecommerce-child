<?php
/**
 * Object Type - Product types
 *
 * Registers product types
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

use WPGraphQL\WooCommerce\Type\WPObject\Product_Types;

/**
 * Class Subscription_Product
 */
class Subscription_Product {
	/**
	 * Registers product types to the WPGraphQL schema
	 */
	public static function register_types(): void {
		self::set_product_model_fields();
		self::register_subscription_product_type();
		self::register_subscription_variable_product_type();
		self::register_subscription_variation_type();
	}

	/**
	 * Adds filters for setting the necessary fields on the model.
	 *
	 * @return void
	 */
	public static function set_product_model_fields() {
		// SubscriptionProduct.
		add_filter( 'graphql_subscription_product_model_use_pricing_and_tax_fields', '__return_true' );
		add_filter( 'graphql_subscription_product_model_use_inventory_fields', '__return_true' );
		add_filter( 'graphql_subscription_product_model_use_virtual_data_fields', '__return_true' );
		add_filter( 'graphql_subscription_product_model_use_variation_pricing_fields', '__return_false' );
		add_filter( 'graphql_subscription_product_model_use_external_fields', '__return_false' );
		add_filter( 'graphql_subscription_product_model_use_grouped_fields', '__return_false' );

		// SubscriptionVariableProduct.
		add_filter( 'graphql_variable-subscription_product_model_use_pricing_and_tax_fields', '__return_true' );
		add_filter( 'graphql_variable-subscription_product_model_use_inventory_fields', '__return_true' );
		add_filter( 'graphql_variable-subscription_product_model_use_virtual_data_fields', '__return_true' );
		add_filter( 'graphql_variable-subscription_product_model_use_variation_pricing_fields', '__return_true' );
		add_filter( 'graphql_variable-subscription_product_model_use_external_fields', '__return_false' );
		add_filter( 'graphql_variable-subscription_product_model_use_grouped_fields', '__return_false' );
	}

	/**
	 * Returns shared fields related to subscriptions
	 *
	 * @param array $fields  Fields array used to overwrite any subscriptions fields.
	 * @return array
	 */
	public static function get_subscription_fields( $fields = [] ) {
		return array_merge(
			[
				'signUpFee'     => [
					'type'        => 'String',
					'description' => __( 'Subscription pricing', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$sign_up_fee = \WC_Subscriptions_Product::get_sign_up_fee( $source->as_WC_Data() );

						return ! empty( $sign_up_fee ) ? $sign_up_fee : null;
					},
				],
				'addToCartText' => [
					'type'        => 'String',
					'description' => __( 'Product\'s add to cart button text description', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$add_to_cart_text = $source->add_to_cart_text();

						return ! empty( $add_to_cart_text ) ? $add_to_cart_text : null;
					},
				],
				'price'         => [
					'type'        => 'String',
					'description' => __( 'Subscription pricing', 'woographql-pro' ),
					'args'        => [
						'exclude' => [ // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
							'type'        => [ 'list_of' => 'SubscriptionPricingPropertiesEnum' ],
							'description' => __( 'Properties to be excluding from the price statement', 'woographql-pro' ),
						],
						'context' => [
							'type'        => 'SubscriptionPriceDisplayContextEnum',
							'description' => __( 'How should price be format? Defaults to simple string', 'woographql-pro' ),
						],
					],
					'resolve'     => static function ( $source, array $args ) {
						$include = [];
						if ( ! empty( $args['exclude'] ) ) {
							foreach ( $args['exclude'] as $property ) {
								$include[ $property ] = 0;
							}
						}

						$format = null;
						if ( ! empty( $args['context'] ) ) {
							$format = $args['context'];
						}

						$price = $source->priceRaw; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
						if ( 'raw' !== $format && ! empty( $price ) ) {
							$price = \WC_Subscriptions_Product::get_price_string(
								$source->as_WC_Data(),
								$include
							);

							if ( empty( $args['exclude'] ) || ! in_array( 'subscription_price', $args['exclude'], true ) ) {
								$price = get_woocommerce_currency_symbol() . $price;
							}
						}

						if ( 'html' !== $format && ! empty( $price ) ) {
							$price = preg_replace( '!\s+!', ' ', wp_strip_all_tags( html_entity_decode( $price ) ) );
						}

						return ! empty( $price ) ? $price : null;
					},
				],
			],
			$fields
		);
	}

	/**
	 * Registers "SubscriptionProduct" type.
	 */
	private static function register_subscription_product_type(): void {
		register_graphql_object_type(
			'SubscriptionProduct',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'A subscription product object', 'woographql-pro' ),
				'interfaces'      => Product_Types::get_product_interfaces(
					[
						'DownloadableProduct',
						'InventoriedProduct',
						'ProductWithDimensions',
						'ProductWithPricing',
					]
				),
				'fields'          => self::get_subscription_fields(),
			]
		);
	}

	/**
	 * Registers "SubscriptionVariableProduct" type.
	 */
	private static function register_subscription_variable_product_type(): void {
		register_graphql_object_type(
			'SubscriptionVariableProduct',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'A subscription variable product object', 'woographql-pro' ),
				'interfaces'      => Product_Types::get_product_interfaces(
					[
						'InventoriedProduct',
						'ProductWithDimensions',
						'ProductWithPricing',
						'ProductWithVariations',
					]
				),
				'fields'          => self::get_subscription_fields(
					[
						'price' => [
							'type'        => 'String',
							'description' => __( 'Subscription pricing', 'woographql-pro' ),
							'args'        => [
								'context' => [
									'type'        => 'SubscriptionPriceDisplayContextEnum',
									'description' => __( 'How should price be format? Defaults to simple string', 'woographql-pro' ),
								],
							],
							'resolve'     => static function ( $source, array $args ) {
								$format = null;
								if ( ! empty( $args['context'] ) ) {
									$format = $args['context'];
								}

								$price = $source->priceRaw; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
								if ( 'raw' !== $format && ! empty( $price ) ) {
									$price = $source->get_price_html();
								}

								if ( 'html' !== $format && ! empty( $price ) ) {
									$price = preg_replace( '!\s+!', ' ', wp_strip_all_tags( html_entity_decode( $price ) ) );
								}

								return ! empty( $price ) ? $price : null;
							},
						],
					]
				),
			]
		);
	}

	/**
	 * Registers "SubscriptionProductVariation" type.
	 *
	 * @return void
	 */
	private static function register_subscription_variation_type() {
		register_graphql_object_type(
			'SubscriptionProductVariation',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'A subscription variable product variation object', 'woographql-pro' ),
				'interfaces'      => [ 'Node', 'ProductVariation' ],
				'fields'          => self::get_subscription_fields(
					[
						'price' => [
							'type'        => 'String',
							'description' => __( 'Subscription pricing', 'woographql-pro' ),
							'args'        => [
								'exclude' => [ // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
									'type'        => [ 'list_of' => 'SubscriptionPricingPropertiesEnum' ],
									'description' => __( 'Properties to be excluding from the price statement', 'woographql-pro' ),
								],
								'context' => [
									'type'        => 'SubscriptionPriceDisplayContextEnum',
									'description' => __( 'How should price be format? Defaults to simple string', 'woographql-pro' ),
								],
							],
							'resolve'     => static function ( $source, array $args ) {
								$include = [];
								if ( ! empty( $args['exclude'] ) ) {
									foreach ( $args['exclude'] as $property ) {
										$include[ $property ] = false;
									}
								}

								$format = null;
								if ( ! empty( $args['context'] ) ) {
									$format = $args['context'];
								}

								$price = $source->priceRaw; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
								if ( 'raw' !== $format && ! empty( $price ) ) {
									$price = \WC_Subscriptions_Product::get_price_string(
										$source->as_WC_Data(),
										$include
									);

									if ( empty( $args['exclude'] ) || ! in_array( 'subscription_price', $args['exclude'], true ) ) {
										$price = get_woocommerce_currency_symbol() . $price;
									}
								}

								if ( 'html' !== $format && ! empty( $price ) ) {
									$price = preg_replace( '!\s+!', ' ', wp_strip_all_tags( html_entity_decode( $price ) ) );
								}

								return ! empty( $price ) ? $price : null;
							},
						],
					]
				),
			]
		);
	}
}
