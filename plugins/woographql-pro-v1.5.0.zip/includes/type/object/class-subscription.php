<?php
/**
 * Object Type - Subscription
 *
 * Registers Subscription type
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

use WPGraphQL\WooCommerce\Model\Order;
use WPGraphQL\WooCommerce\Type\WPObject\Order_Type;

/**
 * Class Subscription
 */
class Subscription {
	/**
	 * Registers types and fields.
	 *
	 * @return void
	 */
	public static function register() {
		add_filter( 'wc_order_statuses', [ self::class, 'register_order_statuses' ] );
		self::register_subscription();
		self::register_customer_subscriptions_field();
		self::register_order_subscriptions_field();
	}

	/**
	 * Registers Subscription as a viewable Order type.
	 *
	 * @param array $order_statuses  Order statuses.
	 *
	 * @return array
	 */
	public static function register_order_statuses( $order_statuses ) {
		$order_statuses = array_merge(
			$order_statuses,
			wcs_get_subscription_statuses()
		);
		return $order_statuses;
	}

	/**
	 * Registers the "Customer" type "subscriptions" field.
	 *
	 * @return void
	 */
	private static function register_customer_subscriptions_field() {
		register_graphql_field(
			'Customer',
			'subscriptions',
			[
				'type'        => [ 'list_of' => 'Subscription' ],
				'description' => __( 'Subscriptions on the order.', 'woographql-pro' ),
				'resolve'     => static function ( $source, array $args ) {
					$user_id = $source->ID;

					// Session ids (guest customers) can't have subscriptions.
					if ( ! is_numeric( $user_id ) ) {
						return null;
					}

					$subscription_ids = \WCS_Customer_Store::instance()->get_users_subscription_ids( absint( $user_id ) );

					return array_map(
						static function ( $subscription_id ) {
							return new Order( $subscription_id );
						},
						$subscription_ids
					);
				},
			]
		);
	}

	/**
	 * Registers the "subscriptions" field to the "Order" type.
	 */
	private static function register_order_subscriptions_field(): void {
		register_graphql_field(
			'Order',
			'subscriptions',
			[
				'type'        => [ 'list_of' => 'Subscription' ],
				'args'        => [
					'limit'  => [ 'type' => 'Integer' ],
					'offset' => [ 'type' => 'Integer' ],
					'order'  => [ 'type' => 'SubscriptionStatusesEnum' ],
				],
				'description' => __( 'Subscriptions on the order.', 'woographql-pro' ),
				'resolve'     => static function ( $source, array $args ) {
					if ( ! empty( $args['limit'] ) ) {
						$args['subscriptions_per_page'] = $args['limit'];
						unset( $args['limit'] );
					}

					$subscriptions = wcs_get_subscriptions_for_order( $source->ID, $args );

					return array_map(
						static function ( $subscription ) {
							return new Order( $subscription );
						},
						$subscriptions
					);
				},
			]
		);
	}

	/**
	 * Returns the "Subscription" type fields.
	 *
	 * @param array $other_fields Extra fields configs to be added or override the default field definitions.
	 * @return array
	 */
	public static function get_fields( $other_fields = [] ) {
		return array_merge(
			[

				'billingPeriod'            => [
					'type'        => 'String',
					'description' => __( 'Subscription billing length.', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						return $source->get_billing_period();
					},
				],
				'billingInterval'          => [
					'type'        => 'String',
					'description' => __( 'Subscription billing interval.', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						return $source->get_billing_interval();
					},
				],
				'CanRenewEarly'            => [
					'type'        => 'Boolean',
					'description' => __( 'If a user can renew an active subscription early.', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						return wcs_can_user_renew_early( $source->ID, $source->customer_id );
					},
				],
				'requiresManualRenewal'    => [
					'type'        => 'Boolean',
					'description' => __( 'Does subscription require the subscriber to renew the subscription manually?', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						return (bool) $source->get_requires_manual_renewal();
					},
				],
				'startDate'                => [
					'type'        => 'String',
					'description' => __( 'The subscription\'s start date', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$date = $source->get_date( 'start' );
						return ! empty( $date ) ? $date : null;
					},
				],
				'trialDate'                => [
					'type'        => 'String',
					'description' => __( 'The subscription\'s trial date', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$date = $source->get_date( 'trial_end' );
						return ! empty( $date ) ? $date : null;
					},
				],
				'lastPaymentDate'          => [
					'type'        => 'String',
					'description' => __( 'The subscription\'s last payment date', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$date = $source->get_date( 'last_order_date_paid' );
						return ! empty( $date ) ? $date : null;
					},
				],
				'nextPaymentDate'          => [
					'type'        => 'String',
					'description' => __( 'The subscription\'s next payment date', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$date = $source->get_date( 'next_payment' );
						return ! empty( $date ) ? $date : null;
					},
				],
				'cancelledDate'            => [
					'type'        => 'String',
					'description' => __( 'The subscription\'s cancelled date', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$date = $source->get_date( 'cancelled' );
						return ! empty( $date ) ? $date : null;
					},
				],
				'endDate'                  => [
					'type'        => 'String',
					'description' => __( 'The subscription\'s end date.', 'woographql-pro' ),
					'resolve'     => static function ( $source ) {
						$date = $source->get_date( 'end' );
						return ! empty( $date ) ? $date : null;
					},
				],
				'resubscribedFrom'         => [
					'type'        => 'Subscription',
					'description' => __( 'The subscription before this one.', 'woographql-pro' ),
					'resolve'     => static function ( $source, $args, $context ) {
						$subscription_id = $source->get_meta( '_subscription_resubscribe', false );
						if ( absint( $subscription_id ) ) {
							return $context->get_loader( 'wc_post' )->load( $subscription_id );
						}

						return null;
					},
				],
				'resubscribedSubscription' => [
					'type'        => 'Subscription',
					'description' => __( 'The resubscription after this subscription.', 'woographql-pro' ),
					'resolve'     => static function ( $source, $args, $context ) {
						$resubscribed_subscriptions = array_filter( $source->get_related_orders( 'ids', 'resubscribe' ), 'wcs_is_subscription' );
						$subscription_id            = reset( $resubscribed_subscriptions );
						if ( absint( $subscription_id ) ) {
							return $context->get_loader( 'wc_post' )->load( $subscription_id );
						}

						return null;
					},
				],
			],
			$other_fields
		);
	}

		/**
		 * Returns the "Subscription" type connections.
		 *
		 * @param array $other_connections Extra connections configs to be added or override the default connection definitions.
		 * @return array
		 */
	public static function get_connections( $other_connections = [] ) {
		return array_merge(
			[
				'removedLineItems' => [
					'toType'         => 'LineItem',
					'connectionArgs' => [],
					'resolve'        => [ Order_Type::class, 'resolve_item_connection' ],
				],
			],
			$other_connections
		);
	}

	/**
	 * Registers the Subscription type.
	 */
	private static function register_subscription(): void {
		// Get order type field definitions.
		$fields      = Order_Type::get_fields();
		$connections = Order_Type::get_connections();

		// Update some order field definitions for subscriptions.
		$fields['createdVia']['description']   = __( 'Where the subscription was created.', 'woographql-pro' );
		$fields['currency']['description']     = __( 'Currency the subscription was created with, in ISO format', 'woographql-pro' );
		$fields['dateCreated']['description']  = __( 'The date the subscription was created', 'woographql-pro' );
		$fields['dateModified']['description'] = __( 'The date the subscription was last modified', 'woographql-pro' );
		$fields['customerId']['description']   = __( 'User ID who owns the subscription.', 'woographql-pro' );
		$fields['status']['type']              = 'SubscriptionStatusesEnum';

		add_filter( 'graphql_order_item_connection_item_type', [ self::class, 'resolve_removed_line_items' ], 10, 5 );
		register_graphql_object_type(
			'Subscription',
			[
				'description' => __( 'A order object', 'woographql-pro' ),
				'interfaces'  => [
					'Node',
					'NodeWithComments',
				],
				'fields'      => self::get_fields( $fields ),
				'connections' => self::get_connections( $connections ),
			]
		);
	}

	/**
	 * Filter the $item_type to allow non-core item types.
	 *
	 * @param string                               $item_type Type of order item to be queried.
	 * @param mixed                                $source    The source that's passed down the GraphQL queries.
	 * @param array                                $args      The inputArgs on the field.
	 * @param \WPGraphQL\AppContext                $context   The AppContext passed down the GraphQL tree.
	 * @param \GraphQL\Type\Definition\ResolveInfo $info      The ResolveInfo passed down the GraphQL tree.
	 *
	 * @return string
	 */
	public static function resolve_removed_line_items( $item_type, $source, $args, $context, $info ) {
		// @codingStandardsIgnoreLine
		if ( 'removedLineItems' === $info->fieldName ) {
			return 'line_item_removed';
		}

		return $item_type;
	}
}
