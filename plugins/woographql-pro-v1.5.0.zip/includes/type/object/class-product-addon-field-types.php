<?php
/**
 * Object Type - "ProductAddonField" child types
 *
 * Registers the product addons types the inherit the "ProductAddonField" interface.
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

use WPGraphQL\AppContext;
use WPGraphQL\WooCommerce\Pro\Type\WPInterface\Product_Addon_Field_Interface;

/**
 * Class Product_Addon_Field_Types
 */
class Product_Addon_Field_Types {
	/**
	 * Registers all product addons types to the WPGraphQL schema.
	 */
	public static function register_field_types(): void {
		self::register_common_types();
		self::register_multiple_choice_type();
		self::register_checkbox_type();
		self::register_short_text_type();
		self::register_long_text_type();
		self::register_file_upload_type();
		self::register_customer_defined_price_type();
		self::register_quantity_type();
		self::register_heading_type();
	}

	/**
	 * Registers common complex types used across the addon types.
	 *
	 * @return void
	 */
	public static function register_common_types() {
		register_graphql_object_type(
			'ProductAddonOption',
			[
				'description' => __( 'Product addon option object', 'woographql-pro' ),

				'fields'      => [
					'label'     => [
						'type'        => 'String',
						'description' => __( 'Option label', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['label'] ) ? $source['label'] : null;
						},
					],
					'priceType' => [
						'type'        => 'ProductAddonPriceAdjustEnum',
						'description' => __( 'Option pricing type', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['price_type'] ) ? $source['price_type'] : null;
						},
					],
					'price'     => [
						'type'        => 'Float',
						'description' => __( 'Option pricing', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['price'] ) ? $source['price'] : null;
						},
					],
					'image'     => [
						'type'        => 'MediaItem',
						'description' => __( 'Option image.', 'woographql-pro' ),
						'resolve'     => static function ( $source, array $args, AppContext $context ) {
							$image_id = ! empty( $source['image'] ) ? absint( $source['image'] ) : null;

							if ( $image_id ) {
								return $context->get_loader( 'post' )->load_deferred( $image_id );
							}

							return null;
						},
					],
				],
			]
		);

		register_graphql_object_type(
			'ProductAddonPriceAdjust',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'Price adjustment object meant to determine how a product price should be adjust when the parent addon is applied to the purchase.', 'woographql-pro' ),
				'fields'          => [
					'type'   => [
						'type'        => 'ProductAddonPriceAdjustEnum',
						'description' => __( 'Method by which the product price should be adjusted.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return null;
						},
					],
					'amount' => [
						'type'        => 'Float',
						'description' => __( 'Amount to be applied. How it is to be applied depends on the "type".', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return 0;
						},
					],
				],
			]
		);

		register_graphql_object_type(
			'ProductAddonFloatRange',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'Float range object meant to define a floating point range for the user to interact with.', 'woographql-pro' ),
				'fields'          => [
					'min' => [
						'type'        => 'Float',
						'description' => __( 'Minimum amount that can be selected.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['min'] ) ? $source['min'] : 0;
						},
					],
					'max' => [
						'type'        => 'Float',
						'description' => __( 'Maximum amount that can be selected.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['max'] ) ? $source['max'] : 0;
						},
					],
				],
			]
		);

		register_graphql_object_type(
			'ProductAddonIntegerRange',
			[
				'eagerlyLoadType' => true,
				'description'     => __( 'Integer range object meant to define a number range for the user to interact with.', 'woographql-pro' ),
				'fields'          => [
					'min' => [
						'type'        => 'Integer',
						'description' => __( 'Minimum amount that can be selected.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['min'] ) ? $source['min'] : 0;
						},
					],
					'max' => [
						'type'        => 'Integer',
						'description' => __( 'Maximum amount that can be selected.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							return ! empty( $source['max'] ) ? $source['max'] : 0;
						},
					],
				],
			]
		);
	}

	/**
	 * Registers the "MultipleChoice" type.
	 *
	 * @return void
	 */
	private static function register_multiple_choice_type() {
		register_graphql_object_type(
			'AddonMultipleChoice',
			[
				'eagerlyLoadType' => true,
				'description'     => __( '"Multiple choice" addon field object.', 'woographql-pro' ),
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => array_merge(
					Product_Addon_Field_Interface::get_fields(),
					[
						'choiceType' => [
							'type'        => 'ProductAddonDisplayAsEnum',
							'description' => __( 'Method of selection for the addon.', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return ! empty( $source['display'] ) ? $source['display'] : null;
							},
						],
						'options'    => [
							'type'        => [ 'list_of' => 'ProductAddonOption' ],
							'description' => __( 'Addon options.', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return ! empty( $source['options'] ) ? $source['options'] : [];
							},
						],
					]
				),
			]
		);
	}

	/**
	 * Registers the "Checkbox" type.
	 *
	 * @return void
	 */
	private static function register_checkbox_type() {
		register_graphql_object_type(
			'AddonCheckbox',
			[
				'eagerlyLoadType' => true,
				'description'     => __( '"Checkbox" addon object.', 'woographql-pro' ),
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => array_merge(
					Product_Addon_Field_Interface::get_fields(),
					[
						'options' => [
							'type'        => [ 'list_of' => 'ProductAddonOption' ],
							'description' => __( 'Addon options.', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return ! empty( $source['options'] ) ? $source['options'] : [];
							},
						],
					]
				),
			]
		);
	}

	/**
	 * Registers the "ShortText" type.
	 *
	 * @return void
	 */
	private static function register_short_text_type() {
		register_graphql_object_type(
			'AddonShortText',
			[
				'eagerlyLoadType' => true,
				'description'     => __( '"Short text" addon field object.', 'woographql-pro' ),
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => array_merge(
					Product_Addon_Field_Interface::get_fields(),
					[
						'restrictions'   => [
							'type'        => 'ProductAddonShortTextRestrictionEnum',
							'description' => __( 'Input restrictions on the addon.', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return ! empty( $source['restrictions_type'] ) ? $source['restrictions_type'] : null;
							},
						],
						'characterLimit' => [
							'type'        => 'ProductAddonIntegerRange',
							'description' => __( 'Input length limit on the addon.', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return [
									'min' => ! empty( $source['min'] ) ? $source['min'] : 0,
									'max' => ! empty( $source['max'] ) ? $source['max'] : null,
								];
							},
						],
					]
				),
			]
		);
	}

	/**
	 * Registers the "LongText" type.
	 *
	 * @return void
	 */
	private static function register_long_text_type() {
		register_graphql_object_type(
			'AddonLongText',
			[
				'description'     => __( '"Long text" addon field object.', 'woographql-pro' ),
				'eagerlyLoadType' => true,
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => array_merge(
					Product_Addon_Field_Interface::get_fields(),
					[
						'characterLimit' => [
							'type'        => 'ProductAddonIntegerRange',
							'description' => __( 'Input length limit on the addon.', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return [
									'min' => ! empty( $source['min'] ) ? $source['min'] : 0,
									'max' => ! empty( $source['max'] ) ? $source['max'] : null,
								];
							},
						],
					]
				),
			]
		);
	}

	/**
	 * Registers the "FileUpload" type.
	 *
	 * @return void
	 */
	private static function register_file_upload_type() {
		register_graphql_object_type(
			'AddonFileUpload',
			[
				'eagerlyLoadType' => true,
				'description'     => __( '"File upload" addon field object.', 'woographql-pro' ),
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => Product_Addon_Field_Interface::get_fields(),
			]
		);
	}

	/**
	 * Registers the "CustomerDefinedPrice" type.
	 *
	 * @return void
	 */
	private static function register_customer_defined_price_type() {
		register_graphql_object_type(
			'AddonCustomerDefinedPrice',
			[
				'eagerlyLoadType' => true,
				'description'     => __( '"Customer defined price" addon field object.', 'woographql-pro' ),
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => array_merge(
					Product_Addon_Field_Interface::get_fields(),
					[
						'priceRangeLimit' => [
							'type'        => 'ProductAddonFloatRange',
							'description' => __( 'Range for whether the customer must set their desired payment amount within', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return [
									'min' => ! empty( $source['min'] ) ? $source['min'] : 0.0,
									'max' => ! empty( $source['max'] ) ? $source['max'] : null,
								];
							},
						],
					]
				),
			]
		);
	}

	/**
	 * Registers the "Quantity" type.
	 *
	 * @return void
	 */
	private static function register_quantity_type() {
		register_graphql_object_type(
			'AddonQuantity',
			[
				'eagerlyLoadType' => true,
				'description'     => __( '"Quantity" addon field object.', 'woographql-pro' ),
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => array_merge(
					Product_Addon_Field_Interface::get_fields(),
					[
						'quantityLimit' => [
							'type'        => 'ProductAddonIntegerRange',
							'description' => __( 'Mininum and maximum amounts that must be purchase upon application of this addon.', 'woographql-pro' ),
							'resolve'     => static function ( $source ) {
								return [
									'min' => ! empty( $source['min'] ) ? $source['min'] : 0.0,
									'max' => ! empty( $source['max'] ) ? $source['max'] : null,
								];
							},
						],
					]
				),
			]
		);
	}

	/**
	 * Registers the "Heading" type.
	 *
	 * @return void
	 */
	private static function register_heading_type() {
		register_graphql_object_type(
			'AddonHeading',
			[
				'eagerlyLoadType' => true,
				'description'     => __( '"Heading" addon object.', 'woographql-pro' ),
				'interfaces'      => [ 'ProductAddonField' ],
				'fields'          => Product_Addon_Field_Interface::get_fields(),
			]
		);
	}
}
