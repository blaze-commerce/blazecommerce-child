<?php
/**
 * WPObject Type - Customer
 *
 * Registers fields to the Customer type.
 *
 * @package WPGraphQL\WooCommerce\Pro\Type\WPObject
 * @since   1.3.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPObject;

/**
 * Class Customer
 */
class Customer {
	/**
	 * Registers selected authorizing_url_fields
	 *
	 * @param array $fields_to_register  Slugs of fields.
	 * @return void
	 */
	public static function register_authorizing_url_fields( $fields_to_register ) {
		if ( in_array( 'change_subscription_payment_method_url', $fields_to_register, true ) ) {
			register_graphql_fields(
				'Customer',
				[
					'changeSubscriptionPaymentMethodUrl'   => [
						'type'        => 'String',
						'description' => __( 'A nonce link to the add change subscription payment method page for the authenticated user. Expires in 24 hours.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							if ( ! is_user_logged_in() ) {
								return null;
							}

							// Get current customer and user ID.
							$customer_id     = $source->ID;
							$current_user_id = get_current_user_id();

							// Return null if current user not user being queried.
							if ( $current_user_id !== $customer_id ) {
								return null;
							}

							// Build nonced url as an unauthenticated user.
							$nonce_name = woographql_setting( 'change_subscription_payment_method_nonce_param', '_wc_change_sub' );
							$url        = add_query_arg(
								[
									'session_id' => $customer_id,
									$nonce_name  => woographql_create_nonce( "change-sub_{$customer_id}" ),
									'sub'        => '%SUBSCRIPTION_ID%',
								],
								site_url( woographql_setting( 'authorizing_url_endpoint', 'transfer-session' ) )
							);

							return esc_url_raw( $url );
						},
					],
					'changeSubscriptionPaymentMethodNonce' => [
						'type'        => 'String',
						'description' => __( 'A nonce for the add change subscription payment page. By default, it expires in 1 hour.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							// Get current customer and user ID.
							$customer_id     = $source->ID;
							$current_user_id = get_current_user_id();

							// Return null if current user not user being queried.
							if ( 0 !== $current_user_id && $current_user_id !== $customer_id ) {
								return null;
							}

							return woographql_create_nonce( "change-sub_{$customer_id}" );
						},
					],
				]
			);
		}//end if

		if ( in_array( 'renew_subscription_payment_method_url', $fields_to_register, true ) ) {
			register_graphql_fields(
				'Customer',
				[
					'renewSubscriptionPaymentMethodUrl'   => [
						'type'        => 'String',
						'description' => __( 'A nonce link to the add renew subscription payment method page for the authenticated user. Expires in 24 hours.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							if ( ! is_user_logged_in() ) {
								return null;
							}

							// Get current customer and user ID.
							$customer_id     = $source->ID;
							$current_user_id = get_current_user_id();

							// Return null if current user not user being queried.
							if ( $current_user_id !== $customer_id ) {
								return null;
							}

							// Build nonced url as an unauthenticated user.
							$nonce_name = woographql_setting( 'renew_subscription_payment_method_nonce_param', '_wc_change_sub' );
							$url        = add_query_arg(
								[
									'session_id' => $customer_id,
									$nonce_name  => woographql_create_nonce( "renew-sub_{$customer_id}" ),
									'sub'        => '%SUBSCRIPTION_ID%',
								],
								site_url( woographql_setting( 'authorizing_url_endpoint', 'transfer-session' ) )
							);

							return esc_url_raw( $url );
						},
					],
					'renewSubscriptionPaymentMethodNonce' => [
						'type'        => 'String',
						'description' => __( 'A nonce for the add renew subscription payment page. By default, it expires in 1 hour.', 'woographql-pro' ),
						'resolve'     => static function ( $source ) {
							// Get current customer and user ID.
							$customer_id     = $source->ID;
							$current_user_id = get_current_user_id();

							// Return null if current user not user being queried.
							if ( 0 !== $current_user_id && $current_user_id !== $customer_id ) {
								return null;
							}

							return woographql_create_nonce( "renew-sub_{$customer_id}" );
						},
					],
				]
			);
		}//end if
	}
}
