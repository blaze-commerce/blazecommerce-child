<?php
/**
 * WPInterface Type - ProductAddonField
 *
 * @package WPGraphQL\WooCommerce\Type\WPInterface
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Pro\Type\WPInterface;

use GraphQL\Error\UserError;
use WPGraphQL\WooCommerce\Pro\Product_Addons_Filters;

/**
 * Class Product_Addon_Field_Interface
 */
class Product_Addon_Field_Interface {
	/**
	 * Registers the "ProductAddonField" interface.
	 *
	 * @return void
	 */
	public static function register_interface() {
		register_graphql_interface_type(
			'ProductAddonField',
			[
				'description' => __( 'Product Add-on object', 'woographql-pro' ),
				'fields'      => self::get_fields(),
				'resolveType' => static function ( $field ) {
					if ( empty( $field['type'] ) ) {
						throw new UserError( __( 'Invalid product addon field object provided.', 'woographql-pro' ) );
					}
					$type = $field['type'];

					/**
					 * Instance of the WPGraphQL TypeRegistry.
					 *
					 * @var \WPGraphQL\Registry\TypeRegistry $type_registry
					 */
					$type_registry = \WPGraphQL::get_type_registry();

					$possible_types = Product_Addons_Filters::get_enabled_addon_types();
					if ( isset( $possible_types[ $type ] ) ) {
						$type = $type_registry->get_type( $possible_types[ $type ] );

						return $type;
					}

					throw new UserError(
						sprintf(
						/* translators: %s: Product addon type */
							__( 'The "%s" product addon file type is not supported by the core WooGraphQL Pro schema.', 'woographql-pro' ),
							$type
						)
					);
				},
			]
		);

		register_graphql_field(
			'Product',
			'addons',
			[
				'type'        => [ 'list_of' => 'ProductAddonField' ],
				'description' => __( 'Product addons connected to this product.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return \WC_Product_Addons_Helper::get_product_addons( $source->ID );
				},
			]
		);
	}

	/**
	 * Returns common fields.
	 *
	 * @return array
	 */
	public static function get_fields() {
		return [
			'fieldName'   => [
				'type'        => [ 'non_null' => 'String' ],
				'description' => __( 'Field unique name', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['field_name'] ) ? $source['field_name'] : null;
				},
			],
			'name'        => [
				'type'        => 'String',
				'description' => __( 'Field name', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['name'] ) ? $source['name'] : null;
				},
			],
			'type'        => [
				'type'        => 'ProductAddonFieldEnum',
				'description' => __( 'Field type', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['type'] ) ? $source['type'] : null;
				},
			],
			'titleFormat' => [
				'type'        => 'ProductAddonTitleFormatEnum',
				'description' => __( 'The way the title should be displayed.', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['title_format'] ) ? $source['title_format'] : null;
				},
			],
			'description' => [
				'type'        => 'String',
				'description' => __( 'Field description', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['description'] ) ? $source['description'] : null;
				},
			],
			'required'    => [
				'type'        => 'Boolean',
				'description' => __( 'Is this field required?', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['required'] ) ? (bool) $source['required'] : false;
				},
			],
			'priceType'   => [
				'type'        => 'ProductAddonPriceAdjustEnum',
				'description' => __( 'Addon\'s method of price adjustment', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['price_type'] ) ? $source['price_type'] : null;
				},
			],
			'price'       => [
				'type'        => 'Float',
				'description' => __( 'Addon\'s price', 'woographql-pro' ),
				'resolve'     => static function ( $source ) {
					return ! empty( $source['price'] ) ? $source['price'] : null;
				},
			],
		];
	}
}
