# Changelog

## [v1.5.0](https://github.com/kidunot89/woographql-pro/tree/v1.5.0) (2023-12-27)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.4.1...v1.5.0)

**Breaking changes:**

- feat: ProductBundle::allowedVariations to variation connection [\#23](https://github.com/kidunot89/woographql-pro/pull/23) ([kidunot89](https://github.com/kidunot89))

**Fixed:**

- fix: better subscription date handling [\#21](https://github.com/kidunot89/woographql-pro/pull/21) ([justlevine](https://github.com/justlevine))

**Other Changes:**

- devops: ProductAddonMutationsTest fixed [\#24](https://github.com/kidunot89/woographql-pro/pull/24) ([kidunot89](https://github.com/kidunot89))

## [v1.4.1](https://github.com/kidunot89/woographql-pro/tree/v1.4.1) (2023-11-01)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.4.0...v1.4.1)

**Fixed:**

- fix: WC extensions removed from plugin dependency list [\#20](https://github.com/kidunot89/woographql-pro/pull/20) ([kidunot89](https://github.com/kidunot89))

## [v1.4.0](https://github.com/kidunot89/woographql-pro/tree/v1.4.0) (2023-09-18)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.3.4...v1.4.0)

**New Features:**

- feat: Support added for Product interfaces [\#19](https://github.com/kidunot89/woographql-pro/pull/19) ([kidunot89](https://github.com/kidunot89))

## [v1.3.4](https://github.com/kidunot89/woographql-pro/tree/v1.3.4) (2023-08-23)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.3.3...v1.3.4)

**Fixed:**

- General bugfixes and improvements [\#18](https://github.com/kidunot89/woographql-pro/pull/18) ([kidunot89](https://github.com/kidunot89))
- fix: return null for guest subscriptions [\#17](https://github.com/kidunot89/woographql-pro/pull/17) ([justlevine](https://github.com/justlevine))

**Other Changes:**

- chore: setup PHPStan and fix [\#16](https://github.com/kidunot89/woographql-pro/pull/16) ([justlevine](https://github.com/justlevine))
- chore: match woographql coding standards [\#15](https://github.com/kidunot89/woographql-pro/pull/15) ([justlevine](https://github.com/justlevine))

## [v1.3.3](https://github.com/kidunot89/woographql-pro/tree/v1.3.3) (2023-07-24)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.3.2...v1.3.3)

**Fixed:**

- fix: ProductAddonInput's  field resolve type changed to \[String\] [\#12](https://github.com/kidunot89/woographql-pro/pull/12) ([kidunot89](https://github.com/kidunot89))

**Other Changes:**

- chore: Version numbers and readmes updated. [\#13](https://github.com/kidunot89/woographql-pro/pull/13) ([kidunot89](https://github.com/kidunot89))

## [v1.3.2](https://github.com/kidunot89/woographql-pro/tree/v1.3.2) (2023-07-20)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.3.1...v1.3.2)

**Fixed:**

- fix: ProductAddonField types visibility issue resolved + HPOS support added. [\#9](https://github.com/kidunot89/woographql-pro/pull/9) ([kidunot89](https://github.com/kidunot89))
- fix: prevent 500 fetch error when license unset [\#8](https://github.com/kidunot89/woographql-pro/pull/8) ([justlevine](https://github.com/justlevine))

**Other Changes:**

- chore: PreRelease v1.3.2 [\#10](https://github.com/kidunot89/woographql-pro/pull/10) ([kidunot89](https://github.com/kidunot89))

## [v1.3.1](https://github.com/kidunot89/woographql-pro/tree/v1.3.1) (2023-05-22)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.3.0...v1.3.1)

**New Features:**

- feat: WooGraphQL v0.13.0 improvements [\#7](https://github.com/kidunot89/woographql-pro/pull/7) ([kidunot89](https://github.com/kidunot89))

## [v1.3.0](https://github.com/kidunot89/woographql-pro/tree/v1.3.0) (2023-04-21)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.2.3...v1.3.0)

**New Features:**

- feat: More product bundle fields added. [\#5](https://github.com/kidunot89/woographql-pro/pull/5) ([kidunot89](https://github.com/kidunot89))

**Fixed:**

- fix: permission issues resolved. [\#6](https://github.com/kidunot89/woographql-pro/pull/6) ([kidunot89](https://github.com/kidunot89))

## [v1.2.3](https://github.com/kidunot89/woographql-pro/tree/v1.2.3) (2023-04-19)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.2.2...v1.2.3)

## [v1.2.2](https://github.com/kidunot89/woographql-pro/tree/v1.2.2) (2023-04-09)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.2.1...v1.2.2)

## [v1.2.1](https://github.com/kidunot89/woographql-pro/tree/v1.2.1) (2023-04-08)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.2.0...v1.2.1)

## [v1.2.0](https://github.com/kidunot89/woographql-pro/tree/v1.2.0) (2023-04-04)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.1.1...v1.2.0)

**New Features:**

- Subscription Refactor and settings relocation. [\#4](https://github.com/kidunot89/woographql-pro/pull/4) ([kidunot89](https://github.com/kidunot89))

## [v1.1.1](https://github.com/kidunot89/woographql-pro/tree/v1.1.1) (2023-03-30)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.1.0...v1.1.1)

**Fixed:**

- bugfix: BundleCartItem and CompositeCartItem now visible to schema [\#3](https://github.com/kidunot89/woographql-pro/pull/3) ([kidunot89](https://github.com/kidunot89))

## [v1.1.0](https://github.com/kidunot89/woographql-pro/tree/v1.1.0) (2023-03-30)

[Full Changelog](https://github.com/kidunot89/woographql-pro/compare/v1.0.0...v1.1.0)

**New Features:**

- feat: Upgrade class implemented. [\#2](https://github.com/kidunot89/woographql-pro/pull/2) ([kidunot89](https://github.com/kidunot89))



\* *This Changelog was automatically generated by [github_changelog_generator](https://github.com/github-changelog-generator/github-changelog-generator)*
