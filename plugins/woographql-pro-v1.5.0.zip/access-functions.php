<?php
/**
 * This file contains access functions for various class methods
 *
 * @package WPGraphQL\WooCommerce\Pro
 * @since 1.0.0
 */

if ( ! function_exists( 'woographql_pro_create_wp_graphql_auth_nonce' ) ) :
	/**
	 * Adds nonce to url.
	 *
	 * @todo Write this function.
	 *
	 * @param string  $url         URL to have the nonce appended.
	 * @param integer $expiration  Expiration time for the nonce.
	 *
	 * @return string
	 */
	function woographql_pro_create_wp_graphql_auth_nonce( string $url, $expiration = 0 ) {
		return $url;
	}
endif;
