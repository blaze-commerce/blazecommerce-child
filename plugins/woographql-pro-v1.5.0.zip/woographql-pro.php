<?php
/**
 * Plugin Name: WooGraphQL Pro
 * Plugin URI: https://woographql.com/pro
 * Description: Adds Woocommerce premium extension functionality to WPGraphQL schema.
 * Version: 1.5.0
 * Author: Geoff Taylor
 * Author URI: https://axistaylor.com
 * Text Domain: woographql-pro
 * Domain Path: /languages
 * License: GPL-3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Requires at least: 5.3
 * Tested up to: 6.2.2
 * Requires PHP: 7.1
 * WC requires at least: 7.9.0
 * WC tested up to: 8.0.2
 * WPGraphQL requires at least: 1.14.0+
 * WooGraphQL requires at least: 0.15.0+
 *
 * @package WPGraphQL\WooCommerce\Pro
 * @author  Geoff Taylor <geoff@axistaylor.com>
 * @license GPL-3 <https://www.gnu.org/licenses/gpl-3.0.html>
 */

namespace WPGraphQL\WooCommerce\Pro;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Setups WooGraphQL Pro constants
 */
function constants(): void {
	// Plugin version.
	if ( ! defined( 'WOOGRAPHQL_PRO_VERSION' ) ) {
		define( 'WOOGRAPHQL_PRO_VERSION', '1.5.0' );
	}
	// Plugin Folder Path.
	if ( ! defined( 'WOOGRAPHQL_PRO_PLUGIN_DIR' ) ) {
		define( 'WOOGRAPHQL_PRO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
	}
	// Plugin Folder URL.
	if ( ! defined( 'WOOGRAPHQL_PRO_PLUGIN_URL' ) ) {
		define( 'WOOGRAPHQL_PRO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	}
	// Plugin Root File.
	if ( ! defined( 'WOOGRAPHQL_PRO_PLUGIN_FILE' ) ) {
		define( 'WOOGRAPHQL_PRO_PLUGIN_FILE', __FILE__ );
	}
	// Whether to autoload the files or not.
	if ( ! defined( 'WOOGRAPHQL_PRO_AUTOLOAD' ) ) {
		define( 'WOOGRAPHQL_PRO_AUTOLOAD', true );
	}
}


/**
 * Returns path to plugin root directory.
 *
 * @return string
 */
function get_plugin_directory() {
	return trailingslashit( WOOGRAPHQL_PRO_PLUGIN_DIR );
}

/**
 * Returns path to plugin "includes" directory.
 *
 * @return string
 */
function get_includes_directory() {
	return trailingslashit( WOOGRAPHQL_PRO_PLUGIN_DIR ) . 'includes/';
}

/**
 * Returns path to plugin "vendor" directory.
 *
 * @return string
 */
function get_vendor_directory() {
	return trailingslashit( WOOGRAPHQL_PRO_PLUGIN_DIR ) . 'vendor/';
}

/**
 * Returns url to a plugin file.
 *
 * @param string $filepath  Relative path to plugin file.
 *
 * @return string
 */
function plugin_file_url( $filepath ) {
	return plugins_url( $filepath, __FILE__ );
}

/**
 * Returns plugin slug name.
 *
 * @return string
 */
function get_plugin_slug() {
	return plugin_basename( __FILE__ );
}

/**
 * Renders admin notice for error.
 *
 * @param string $msg Error message.
 */
function add_admin_notice( $msg ): void {
	add_action(
		'admin_notices',
		static function () use ( $msg ) {
			?>
			<div class="notice notice-error">
				<p>
					<?php echo wp_kses_post( $msg ); ?>
				</p>
			</div>
			<?php
		}
	);
}

/**
 * Renders admin notice for missing dependencies.
 *
 * @param string $url  URL to dependency.
 * @param string $name Name of dependency.
 *
 * @return void
 */
function add_missing_dependencies_notice( $url, $name ) {
	add_admin_notice(
		sprintf(
			/* translators: dependency not ready error message */
			'<a href="%1$s" target="_blank">%2$s</a> must be active for "WooGraphQL Pro" to work',
			esc_attr( $url ),
			esc_html( $name )
		)
	);
}

// Load constants.
constants();

// Confirm WC HPOS compatibility.
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

/**
 * Initializes WooGraphQL Pro
 */
require_once WOOGRAPHQL_PRO_PLUGIN_DIR . 'includes/class-woographql-pro.php';
WooGraphQL_Pro::instance();

// Load access functions.
require_once get_plugin_directory() . 'access-functions.php';

/**
 * Initialize Updater.
 */
require_once WOOGRAPHQL_PRO_PLUGIN_DIR . 'includes/class-upgrade.php';
$woographql_pro_upgrade = new Upgrade();

register_activation_hook(
	__FILE__,
	[ $woographql_pro_upgrade, 'on_activation' ]
);

register_deactivation_hook(
	__FILE__,
	[ $woographql_pro_upgrade, 'on_deactivation' ]
);
