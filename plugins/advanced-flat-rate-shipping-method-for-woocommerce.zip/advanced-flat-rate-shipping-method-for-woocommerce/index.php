<?php
/**
 * Plugin's main file
 *
 * @package index
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
