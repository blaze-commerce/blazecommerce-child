=== Advanced Flat Rate Shipping For WooCommerce ===
Contributors: dots, jitendrabanjara1991
Donate link: https://www.multidots.com
Tags: comments, spam
Requires at least: 5.0
Tested up to: 6.5.2
Requires PHP: 5.7
Stable tag: 4.7.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters. No markup here.

== Description ==

This is the long description.  No limit, and you can use Markdown ( as well as in the following sections ).

For backwards compatibility, if this section is missing, the full length of the short description will be used, and
Markdown parsed.

A few notes about the sections above:

*   "Contributors" is a comma separated list of wp.org/wp-plugins.org usernames
*   "Tags" is a comma separated list of tags that apply to the plugin
*   "Requires at least" is the lowest version that the plugin will work on
*   "Tested up to" is the highest version that you've *successfully used to test the plugin*. Note that it might work on
higher versions... this is just the highest one you've verified.
*   Stable tag should indicate the Subversion "tag" of the latest stable version, or "trunk," if you use `/trunk/` for
stable.

    Note that the `readme.txt` of the stable tag is the one that is considered the defining one for the plugin, so
if the `/trunk/readme.txt` file says that the stable tag is `4.4`, then it is `/tags/4.4/readme.txt` that'll be used
for displaying information about the plugin.  In this situation, the only thing considered from the trunk `readme.txt`
is the stable tag pointer.  Thus, if you develop in trunk, you can update the trunk `readme.txt` to reflect changes in
your in-development version, without having that information incorrectly disclosed about the current stable version
that lacks those changes -- as long as the trunk's `readme.txt` points to the correct stable tag.

    If no stable tag is provided, it is assumed that trunk is stable, but you should specify "trunk" if that's where
you put the stable version, in order to eliminate any doubt.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `advanced-flat-rate-shipping-for-woocommerce.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action( 'plugin_name_hook' ); ?>` in your templates

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.( png|jpg|jpeg|gif ). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt ( tags or trunk ). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
( or jpg, jpeg, gif ).
2. This is the second screen shot

== Changelog ==
2024-04-19 - version 4.7.8
* [Bug Fix] Fixed product save issue related to the 'cart contains product' field.
* [Enhancement] Compatible with WooCommerce 8.8.x
* [Enhancement] Compatible with WordPress 6.5.x

2023-10-31 - version 4.7.7
* [Bug Fix] Unable to add Cart Contains Product rule.
* [Bug Fix] Unable to delete the zone.
* [Bug Fix] Minor fixes related to zone type zipcode.
* [Bug Fix] Minor fixes related to weight rule
* [Enhancement] Compatible with WooCommerce Subscriptions plugin
* [Bug Fix] Compatible with PHP 8.2
* [Update] Compatible with WordPress 6.3.x
* [Update] Compatible with WooCommerce 8.2.x

2023-08-10 - version 4.7.6.1
* [Enhancement] Plugin compatibility with WooCommerce High-Performance Order Storage (HPOS)
* [Enhancement] Compatible with WooCommerce 8.0.x
* [Enhancement] Compatible with WordPress 6.3.x

2022-12-21 - version 4.7.6
* [Bug Fix] Minor fixes related to the load variable products list.
* [Bug Fix] Minor fixes related to the search products by SKU.
* [Bug Fix] Minor fixes related to the drag and drop shipping rules.
* [Bug Fix] Minor fixes related to the load city based shipping zones.
* [Bug Fix] Minor fixes related to the (===) condition with product specific shipping rule.
* [Bug Fix] Minor fixes related to the allow free shipping with minimum order amount.
* [Bug Fix] Compatible with PHPCS coding standard and PHP8.
* [Enhancement] Improvise the UI to hide "Want to force customers to select a shipping method?" option once the "Allow to customer choose" option is selected.
* [Update] Compatible with WooCommerce 7.2.x
* [Update] Compatible with WordPress 6.1.x

2022-7-12 - version 4.7.5
* Fixed - Cart page warning
* Fixed - Multisite activation issue
* Fixed - Duplicate shipping method issue
* Fixed - Allow Free Shipping option considering the amount with tax
* Compatible with WooCommerce 6.8.x
* Compatible with WordPress 6.0.x

2022-5-10 - version 4.7.4
* Fixed - Blank Screen issue while Adding/Editing Pages
* Compatible with WooCommerce 6.4.x
* Compatible with WordPress 5.9.x

2022-3-31 - version 4.7.3
* Enhancement — Fully compatible with the WoodMart theme
* Fixed — Resolve issue related to the only first-page shipping methods display
* Fixed — Force all option shipping tax issue
* Compatible with WooCommerce 6.3.x
* Compatible with WordPress 5.9.x

2022-1-26 - version 4.7.2
* Fixed - tag-based rules not working with variable products
* Fixed - Minor bug fixed related to the Uncaught Error: Undefined variable
* Compatible with WooCommerce 6.1.x
* Compatible with WordPress 5.9.x

2021-12-22 - version 4.7.1
* Fixed - Minor bug fixed related to the Uncaught Error: Call to undefined method
* Compatible with WooCommerce 6.0.x
* Compatible with WordPress 5.8.x

2021-12-07 - version 4.7
* New - Master Settings - Hide other shipping methods when free shipping is available
* New - Master Settings - Want to force customers to select a shipping method
* New - General Settings - Allow Free Shipping
* New - General Settings - Each Weight Rule
* New - General Settings - Each Quantity Rule
* New - General Settings - Show only for logged-in users
* New - General Settings - Default selected shipping
* New - Shipping Method Rules - City-based rules
* New - Zone-based Rules - Zone-based city
* New - Product Specific - Cart contains a variable product
* New - Product Specific - Cart contains category's product
* New - Product Specific - Cart contains tag's product
* New - Product Specific - Cart contains SKU's product
* Compatible with WooCommerce 5.9.x
* Compatible with WordPress 5.8.x

2021-09-01 - version 4.6
* Fixed - Minor bug
* Compatible with WooCommerce Product Bundles
* Compatible with YITH WooCommerce Product Bundles
* Compatible with WooCommerce 5.6.x
* Compatible with WordPress 5.8.x

2021-06-29 - version 4.5
* Fixed - Call to a member function get_slugs()
* Compatible with WooCommerce 5.4.x
* Compatible with WordPress 5.7.x

2021-06-01 - version 4.4
* Fixed - Attribute based condition not working
* Fixed - Minor bug
* Compatible with WooCommerce 5.3.x
* Compatible with WordPress 5.7.x

2021-01-04 - version 4.3
* Fixed - Multiple state selected then only first working
* Fixed - Fully compatible with WPML plugin
* Compatible with WooCommerce 4.8.x
* Compatible with WordPress 5.6.x

2020-08-06 - version 4.2
* Fix - Validation issue - Product category subtotal in advance pricing rules
* Fix - Shipping tax issue in cart, checkout, order and admin order side - When select forceall shipping with separate shipping option
* Fix - When enter postcode with lowercase at front side and define admin side with uppercase then it was issuing
* New - Cart contains product qty in general rule
* Fix - Cart contains category product issue with variable products in apply per qty section
* Fix - Shipping class issue with variable product - When change variation for variable product to virtual
* Compatible with WooCommerce 4.3.x
* Compatible with WordPress 5.4.x

2020-07-29 - version 4.1
* Minor bug fixing.
* Compatible with WooCommerce 4.0.x
* Compatible with WordPress 5.4.x

2020-05-06 - version 4.1
* Minor bug fixing.
* Compatible with WooCommerce 4.0.x
* Compatible with WordPress 5.4.x

2019-10-25 - version 4.0
* Initial release

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 0.5 =
This version fixes a security related bug.  Upgrade immediately.

== Arbitrary section ==

You may provide arbitrary sections, in the same format as the ones above.  This may be of use for extremely complicated
plugins where more information needs to be conveyed that doesn't fit into the categories of "description" or
"installation."  Arbitrary sections will be shown below the built-in sections outlined above.

== A brief Markdown Example ==

Ordered list:

1. Some feature
1. Another feature
1. Something else about the plugin

Unordered list:

* something
* something else
* third thing

Here's a link to [WordPress]( http://wordpress.org/ "Your favorite software" ) and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`