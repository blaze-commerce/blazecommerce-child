<div class="blaze-wooless-draggable-panel">
	<div class="blaze-wooless-draggable-panel-container">
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="text">
			<div class="content">Text</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="textarea">
			<div class="content">Text Area</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="callToAction">
			<div class="content">Call to action</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="categories">
			<div class="content">Featured Categories</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="cardGroup">
			<div class="content">Card Group</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="cardGroupSlider">
			<div class="content">Card Group Slider</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="singleImage">
			<div class="content">Single Image</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="multipleImage">
			<div class="content">Multiple Image</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="list">
			<div class="content">List</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="menu">
			<div class="content">Menu</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="embedCode">
			<div class="content">HTML Embed Code</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="socialIcons">
			<div class="content">Social Icons</div>
		</div>
		<div class="blaze-wooless-draggable-block" data-block_type="multiple" data-block_id="multipleLinks">
			<div class="content">Multiple Links</div>
		</div>
	</div>
</div>