<div class="blaze-wooless-draggable-canvas-container">
	<?php do_action( 'before_wooless_draggable_canvas' ) ?>
	<div class="blaze-wooless-draggable-canvas"></div>
	<div id="block-config" class="modal">
		<div class="content"></div>
		<div class="actions">
			<button class="button button-primary save-config">Save</button>
		</div>
	</div>
</div>