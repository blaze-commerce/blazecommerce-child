<div class="express-checkout-container">
    <div class="express-title">
        <span class="line">
            <h2><span>Express Checkout</span></h2>
        </span>
    </div>
    <div class="express-content">
        <?php do_action( 'blaze_express_checkout' ); ?>
    </div>
</div>
                