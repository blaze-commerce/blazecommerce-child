<div class="accordion-item">
    <div class="payment-accordion accordion-title"><?php _e( 'Shipping & Payment', 'blaze-online-checkout' ) ?></div>
    <div class="accordion-content payment-accordion-content">
        <?php woocommerce_checkout_payment(); ?>
    </div>

</div>
