(function e(){
  var e = document.createElement("script");
  e.type = "text/javascript", e.async = true, e.src = "https://cdn-widgetsrepository.yotpo.com/v1/loader/" + yotpo_settings.app_key;
  var t = document.getElementsByTagName("script")[0];
  t.parentNode.insertBefore(e,t)
})();
