<article class='jdgm-widget jdgm-all-reviews-widget'>
	<style class='jdgm-temp-hiding-style'>.jdgm-all-reviews-widget{ display: none }</style>
	<?php echo $all_reviews['all_reviews_header']; ?>
	<div class='jdgm-all-reviews__body'>
		<?php echo $all_reviews['all_reviews']; ?>
	</div>
</article>