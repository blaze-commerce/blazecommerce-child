<div class='jdgm-widget jdgm-ugc-media-wrapper'>
  <?php echo $widget['ugc_media_grid']; ?>
</div>
