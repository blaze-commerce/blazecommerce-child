<div style="clear:both;"></div>
<div id='judgeme_product_reviews' class='jdgm-widget jdgm-review-widget' data-product-title='<?php echo $product->get_title(); ?>' data-id='<?php echo esc_attr( $id ); ?>'>
	<?php echo $body['widget']; ?>
</div>
<div style="clear:both;"></div>