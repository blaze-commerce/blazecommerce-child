<div class='jdgm-widget jdgm-popup-widget-wrapper'>
  <?php echo $widget['popup_widget']; ?>
</div>
