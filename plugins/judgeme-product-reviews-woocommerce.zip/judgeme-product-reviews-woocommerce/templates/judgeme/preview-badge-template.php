<div class='jdgm-widget jdgm-preview-badge' data-id='<?php echo esc_attr( $id ); ?>'>
	<?php echo $body['badge']; ?>
</div>
