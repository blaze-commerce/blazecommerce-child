<!-- Start of Judge.me Core -->
<?php echo $setting['settings']; ?>
<?php echo $html_miracle; ?>

<script data-cfasync='false' class='jdgm-script'>
!function(e){window.jdgm=window.jdgm||{},jdgm.CDN_HOST="https://<?php echo $jdgm_cdn_domain ?>/",
jdgm.docReady=function(d){(e.attachEvent?"complete"===e.readyState:"loading"!==e.readyState)?
setTimeout(d,0):e.addEventListener("DOMContentLoaded",d)},jdgm.loadCSS=function(d,t,o,a){
!o&&jdgm.loadCSS.requestedUrls.indexOf(d)>=0||(jdgm.loadCSS.requestedUrls.push(d),
(a=e.createElement("link")).rel="stylesheet",a.class="jdgm-stylesheet",a.media="nope!",
a.href=d,a.onload=function(){this.media="all",t&&setTimeout(t)},e.body.appendChild(a))},
jdgm.loadCSS.requestedUrls=[],jdgm.docReady(function(){(window.jdgmLoadCSS||e.querySelectorAll(
".jdgm-widget, .jdgm-all-reviews-page").length>0)&&(jdgmSettings.widget_load_with_code_splitting?
parseFloat(jdgmSettings.widget_version)>=3?jdgm.loadCSS(jdgm.CDN_HOST+"widget_v3/base.css"):
jdgm.loadCSS(jdgm.CDN_HOST+"widget/base.css"):jdgm.loadCSS(jdgm.CDN_HOST+"shopify_v2.css"))})}(document);
</script>
<script async data-cfasync="false" type="text/javascript" src="https://<?php echo $jdgm_cdn_domain ?>/loader.js"></script>
<noscript><link rel="stylesheet" type="text/css" media="all" href="https://<?php echo $jdgm_cdn_domain ?>/shopify_v2.css"></noscript>
<!-- End of Judge.me Core -->
