This folder should contain all the views used by the plugin.
