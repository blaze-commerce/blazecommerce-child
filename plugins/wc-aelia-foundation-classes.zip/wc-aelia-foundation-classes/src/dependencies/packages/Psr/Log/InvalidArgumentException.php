<?php

namespace Aelia\Dependencies\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
