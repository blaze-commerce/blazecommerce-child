<?php

defined( 'ABSPATH' ) or exit;

?>
<div id="pwgc-section-designer" class="pwgc-section" style="<?php pwgc_dashboard_helper( 'designer', 'display: block;' ); ?>">
    <?php
        require_once( 'designer-main.php' );
    ?>
</div>
