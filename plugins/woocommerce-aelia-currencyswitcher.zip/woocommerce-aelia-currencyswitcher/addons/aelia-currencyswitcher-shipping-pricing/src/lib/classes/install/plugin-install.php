<?php
namespace Aelia\WC\CurrencySwitcher\ShippingPricing;
if(!defined('ABSPATH')) exit; // Exit if accessed directly

class WC_Aelia_CS_ShippingPricing_Plugin_Install extends \Aelia\WC\Aelia_Install {
	// Dummy Installer class
}
