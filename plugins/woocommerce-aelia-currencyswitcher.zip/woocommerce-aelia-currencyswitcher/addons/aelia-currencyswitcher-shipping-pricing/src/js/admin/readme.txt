This folder should contain all the JavaScript files used in the Administration section.
