/**
 * This file used to contain scripts that had to be loaded on all admin pages.
 * The scripts it contained are no longer needed, but the files needs to be enqueued and
 * loaded, so that it can be localised with a call to wp_localize_script(). This logic
 * will be refactored and simplified in future releases
 *
 * @since 5.0.5.230703
 * @see WC_Aelia_CurrencySwitcher::localize_admin_scripts()
 */